# Deployment

How to build, run, and deploy. **Note:** several production controls are not yet in place — see the [production-readiness checklist](audit-2026-07/09-PRODUCTION-READINESS-CHECKLIST.md) before a public deploy.

## Prerequisites
- Node.js (ESM; Express 5 — Node 18+).
- PostgreSQL instance + connection string.
- Brevo account (transactional email).

## Local development
```bash
# Server
cd server
cp .env.example .env         # fill in DATABASE_URL, JWT secrets, Brevo, FRONTEND_URL
npm install
# apply migrations by hand (no runner) — see below
npm run dev                  # nodemon src/index.js  → http://localhost:3000

# Client
cd ../client
echo "VITE_API_BASE_URL=http://localhost:3000/api" > .env
npm install
npm run dev                  # vite → http://localhost:5173
```

## Scripts
| App | Script | Does |
|-----|--------|------|
| server | `npm run dev` | nodemon `src/index.js` |
| server | `npm start` | `node src/index.js` |
| server | `npm test` | **placeholder — no tests** (`exit 1`) |
| client | `npm run dev` | Vite dev server |
| client | `npm run build` | `tsc --noEmit -p tsconfig.app.json && vite build` (typecheck-gated) |
| client | `npm run preview` | serve the built bundle |

## Database migrations
**There is no migration runner.** Migrations in `server/src/migrations/001…037` are applied **by hand**, in order, e.g.:
```bash
for f in server/src/migrations/0*.sql; do psql "$DATABASE_URL" -f "$f"; done
```
⚠️ **This will fail on a clean DB** — migration 003 references `drives` before 010 creates it, and 004 indexes non-existent columns ([DATABASE.md](DATABASE.md)). Until fixed (audit P2-1/P2-2), bootstrap by applying tables in dependency order or restore from a known-good dump. **Strongly recommended:** adopt a runner (`node-pg-migrate`/`dbmate`) and generate a `schema.sql` baseline.

After changing the schema, apply your migration to each environment and update [schema.md](../schema.md).

## Production build & serve
- **Client:** `npm run build` → static assets in `client/dist/`; serve via a CDN/static host or the reverse proxy. No source maps are emitted.
- **Server:** `node src/index.js` behind a reverse proxy (TLS termination). Set all env vars via the platform's secret injection, not a shipped `.env`.
- Ensure `server/src/deferred/` and `server/credentials/` are **excluded** from the production image.

## Before going live (minimum)
From [audit-2026-07/08-REMEDIATION-PLAN.md](audit-2026-07/08-REMEDIATION-PLAN.md) Phase 0 + Phase 1:
- Fix the authorization gaps (VULN-01–04) and remove the seed credential (VULN-05).
- Add `helmet`, a CORS allow-list (`FRONTEND_URL`), rate limiting on `/auth/*`, body-size limit, compression.
- Add a central error handler + 404, graceful shutdown (`SIGTERM → pool.end()`), and pool limits + `statement_timeout`.
- Add `GET /healthz` + `GET /readyz` for the load balancer/orchestrator.
- Stand up CI (typecheck + lint + the authz integration tests).

## Runtime topology
```
[CDN / static host]  ── client/dist (SPA)
        │  calls VITE_API_BASE_URL
        ▼
[reverse proxy / TLS]  ──►  [Node/Express app(s)]  ──►  [PostgreSQL]
                                     └── Brevo (email, outbound)
```
The app is stateless (JWT, no session store), so it scales horizontally behind the proxy. The only shared state is Postgres.

## Rollback
No down-migrations exist. Roll back application code via your deploy tool; roll back schema via a DB restore (take a snapshot before applying migrations). Adding reversible migrations is an audit recommendation (P2-1).
