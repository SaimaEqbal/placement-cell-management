# Backend

Express 5 (ESM), `pg` with raw parameterized SQL, Zod validation, JWT auth. Entry: [server/src/index.js](../server/src/index.js).

## Layering (current)
```
routes/         → HTTP surface; assemble the middleware chain per endpoint
middleware/     → auth (JWT), role (requireX), *Middleware (Zod validators)
controllers/    → parse request + business logic + SQL + shape response  (no service layer yet)
lib/            → pure/shared helpers: cgpa, dbError, announcements, schema (Zod schemas)
services/       → emailService (Brevo)
config/db.js    → pg Pool (single shared instance)
migrations/     → 001–037, applied by hand
deferred/       → archived Google-Drive upload feature (not mounted)
```
There is **no service/repository layer** — controllers hold both HTTP and SQL. The audit recommends extracting services (workflow, eligibility) and repositories; see [07-ARCHITECTURE-REVIEW.md](audit-2026-07/07-ARCHITECTURE-REVIEW.md) §1.

## Middleware chain
Typical protected route: `auth → requireX → validateBody(Zod) → controller`. **Gotcha:** `company-post` routes run the validator *before* `requireAdmin` — role checks should come first (VULN/API-design). `auth` reloads role from the DB every request.

## Controllers (size + role)
| Controller | ~Lines | Notes |
|-----------|--------|-------|
| `driveController.js` | 1380 | CRUD + eligibility + shortlist + 6 workflow transitions + history + dates + notifications. **Extraction candidate.** |
| `authController.js` | 630 | ~300 lines are dead commented-out old auth — delete. |
| `tpcController.js` | 621 | verification pipeline + SPC promote/assign |
| `studentController.js` | 583 | profile CRUD + self-upsert (allowlisted, CGPA-derived) |
| `invitationController.js` | 374 | invite + complete + role change |
| `companyPostController.js` | 174 | announcements (uses `lib/announcements`) |
| `companyController.js` | 161 | company CRUD |
| `notificationController.js` | 147 | HTTP handlers **+ internal helpers** imported by other controllers (should be a service) |
| `spcController.js` | 118 | assignment-scoped verify/reject |

## Shared libraries
- **`lib/cgpa.js`** — server-authoritative weighted CGPA (mirror of the client's `cgpa.ts`). Never accept CGPA from clients.
- **`lib/dbError.js`** — `pgErrorResponse(error, fallback)` maps SQLSTATE → `{status, message}`; keeps stack traces off the wire.
- **`lib/announcements.js`** — `insertAnnouncement`, `replaceAttachments`, `ATTACHMENTS_SUBQUERY`; shared by drive + company-post controllers (good reuse).
- **`lib/schema.js`** — all Zod schemas (create/update student, self-profile, TPC, company, drive, round actions, company-post). Some `.strict()`, some strip unknown keys (intentional against `cgpa` injection).

## Transactions
Every multi-step mutation uses `pool.connect()` + `BEGIN`/`COMMIT`/`ROLLBACK` in `try/catch/finally` with `client.release()` in `finally`. The drive workflow additionally loads the parent drive `FOR UPDATE` to serialize concurrent admins. **No connection leaks found.** When adding a transition, keep the domain change, the `drive_round_history` append, and any notifications in the *same* transaction (INV-11, BR-25).

## SQL safety
All queries are parameterized (`$1, $2…`). The three dynamic-SQL sites (TPC filters, drive history filter, self-profile partial upsert) build only placeholder indices and column names from **hardcoded allowlists** — never interpolate user values. Preserve this pattern for any new dynamic query.

## Error handling
Each controller try/catches individually; there is **no central Express error handler** (audit recommends adding one + a 404 handler + request ids). `signup` leaks `error.message` — make it generic like the others.

## Adding an endpoint (recipe)
1. Add the Zod schema to `lib/schema.js` and a validator in the relevant `*Middleware.js`.
2. Add the controller function (parameterized SQL; transaction if multi-step; append history + notifications if it changes drive/verification state).
3. Register the route with the chain `auth → requireX → validate → controller` (**role before validate**).
4. Add the query key + hook + service on the client ([FRONTEND.md](FRONTEND.md)).
5. Update [API.md](API.md), the [authorization matrix](audit-2026-07/02-AUTHORIZATION-MATRIX.md), and any affected [INVARIANTS.md](INVARIANTS.md)/[STATE_MACHINES.md](STATE_MACHINES.md).

See [CONVENTIONS.md](CONVENTIONS.md) for standards and pitfalls.
