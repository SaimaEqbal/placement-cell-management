# Production Readiness Audit — Executive Summary

**Date:** 2026-07-15
**Scope:** Full-stack placement-cell management portal — React/Vite/TanStack Query client + Express 5 / PostgreSQL (`pg`) server, manual SQL migrations 001–037.
**Method:** Static review of routes, controllers, middleware, migrations, and the client data layer; `npm audit`; git history scan for committed secrets. No code was changed as part of this audit.

> **Relationship to the existing `audit/` directory.** The 21 files under `audit/` (dated 2026-07-06) are a point-in-time snapshot taken at roughly migration 019. They are now ~18 migrations stale: their single most-repeated "Critical" finding — *"no migration creates `drive_students`"* — was fixed by migration 020, and they predate drive rounds (024/026/028), shortlisting, the announcements/attachments rework (032/033), allowed-batches (036) and min-CGPA-throughout (037). **This report supersedes `audit/` for all security, authorization, database, and query findings.** The old directory is left in place for historical reference only.

---

## Go / No-Go

**Not production ready.** There are broken-access-control and PII-exposure defects reachable by any authenticated user, plus a hardcoded credential in a seed migration. None are architecturally deep — the app is well-structured and the SQL layer is genuinely safe against injection — but the authorization gaps and the absence of baseline hardening (CORS lockdown, rate limiting, security headers, connection-pool limits) must be closed before any public deployment.

Estimated effort to a **minimum production-safe state (P0 + P1)**: **~6–9 developer-days.** Full checklist to a mature posture (P0–P3): **~5–7 developer-weeks.**

---

## Top risks (ranked)

| # | Severity | Finding | Evidence |
|---|----------|---------|----------|
| 1 | **Critical** | `POST /students` has no role guard — any authenticated user (including a student) can create arbitrary student records. | [studentRoutes.js:29](../../server/src/routes/studentRoutes.js) |
| 2 | **Critical** | Hardcoded plaintext password `1234` seeded as an admin `password_hash` (bcrypt-incompatible, but a real admin account with a real email). | [007_insert_admin.sql](../../server/src/migrations/007_insert_admin.sql) |
| 3 | **High** | Drive shortlist & round-history endpoints leak other students' PII (name, roll number, branch, CGPA) to any authenticated user; no ownership/role scoping. | [driveRoutes.js:50](../../server/src/routes/driveRoutes.js), [:83](../../server/src/routes/driveRoutes.js) |
| 4 | **High** | SPC can read **any** student's full profile, violating the intended model (SPC should see only students assigned to them). `GET /students`, `GET /students/:id` are gated only by `requireAdminTPCSPC`. | [studentRoutes.js:28](../../server/src/routes/studentRoutes.js), [:32](../../server/src/routes/studentRoutes.js) |
| 5 | **High** | No CORS allow-list, no `helmet`, no rate limiting, no request-body size cap, no central error handler, no graceful shutdown. | [index.js:12](../../server/src/index.js) |
| 6 | **High** | 7-day access JWT with no refresh, rotation, or revocation. Logout cannot invalidate a token; a leaked token is valid for a week. | [authController.js:518](../../server/src/controllers/authController.js) |
| 7 | **Medium** | Connection pool created with only a connection string — no `max`, timeouts, `statement_timeout`, or TLS config. A few slow queries can exhaust the default 10-connection pool. | [db.js:8](../../server/src/config/db.js) |
| 8 | **Medium** | `company_posts.posted_by` is `UUID NOT NULL … ON DELETE SET NULL` — a self-contradicting FK that errors when a posting user is deleted. | [013_create_company_posts.sql:11](../../server/src/migrations/013_create_company_posts.sql) |
| 9 | **Medium** | Client bundles `xlsx` (SheetJS) — a high-severity prototype-pollution + ReDoS dependency with no upstream fix. | `client/package.json` |
| 10 | **Medium** | No automated tests anywhere; no ESLint/Prettier; manual migrations with no runner (live DB can silently drift from the SQL files). | repo-wide |

---

## What is already solid

The audit deliberately records the strong points so remediation does not "fix" them:

- **SQL injection: not present.** Every user-facing query is parameterized. The three dynamic-SQL sites build only placeholder indices and column names from **hardcoded allowlists**, never interpolating user values ([studentController.js:446](../../server/src/controllers/studentController.js), [tpcController.js:326](../../server/src/controllers/tpcController.js), [driveController.js:1255](../../server/src/controllers/driveController.js)).
- **Stack traces are never returned to clients** — controllers map DB errors through `lib/dbError.js` to generic messages (one exception: `signup`, see report).
- **Passwords** are bcrypt-hashed (cost 12 in the main flow); `forgot-password` is non-enumerating; email/reset tokens use a separate secret with a `purpose` claim.
- **Frontend has no secrets** — one public `VITE_API_BASE_URL`, no source maps in the production build, and zero `console.*` calls in `src`.
- **Transaction discipline** in the drive workflow is careful: every mutating endpoint loads the parent drive `FOR UPDATE` and appends to an append-only history table in the same transaction.
- **`.env` files and credentials were never committed** — git history is clean; only `.env.example` is tracked.

---

## Document index

| File | Purpose |
|------|---------|
| [01-VULNERABILITY-REPORT.md](01-VULNERABILITY-REPORT.md) | Every security finding with severity, evidence, exploit scenario, remediation. |
| [02-AUTHORIZATION-MATRIX.md](02-AUTHORIZATION-MATRIX.md) | Route-by-route auth / role / scope table (all 47 endpoints). |
| [03-DATABASE-REVIEW.md](03-DATABASE-REVIEW.md) | Schema, constraints, indexes, FK/cascade, migration hygiene. |
| [04-QUERY-PERFORMANCE.md](04-QUERY-PERFORMANCE.md) | Problem queries with optimized SQL and expected impact. |
| [05-TANSTACK-QUERY-AUDIT.md](05-TANSTACK-QUERY-AUDIT.md) | Caching, invalidation, retry, and waterfall review of the client data layer. |
| [06-API-DESIGN.md](06-API-DESIGN.md) | REST consistency, pagination, error shape, status-code conventions. |
| [07-ARCHITECTURE-REVIEW.md](07-ARCHITECTURE-REVIEW.md) | Backend/frontend structure, logging, monitoring, hardening, testing strategy. |
| [08-REMEDIATION-PLAN.md](08-REMEDIATION-PLAN.md) | Phased plan (P0–P3), prioritized, with per-fix effort estimates. |
| [09-PRODUCTION-READINESS-CHECKLIST.md](09-PRODUCTION-READINESS-CHECKLIST.md) | Sign-off checklist. |

A companion living-documentation pack (architecture, workflows, invariants, state machines) is in [`docs/`](../). See [docs/README.md](../README.md).
