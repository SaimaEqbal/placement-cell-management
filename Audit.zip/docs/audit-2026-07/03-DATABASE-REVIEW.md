# Database Architecture Review

Source of truth: [schema.md](../../schema.md) (column dump, 2026-07-12) + migrations `001`–`037` in [server/src/migrations/](../../server/src/migrations/). The database is PostgreSQL, accessed via `pg` with raw SQL (no ORM).

---

## 1. Schema & normalization

14 tables, broadly 3NF. Core entities and relationships:

```
users (uuid PK, role, is_verified)
 ├─1:1─ students     (user_id UNIQUE)      -- student profile + marks + review_status
 ├─1:1─ tpc          (user_id UNIQUE)      -- staff, oversees one department
 └─1:1─ spc          (user_id UNIQUE)      -- promoted student, verifies assigned students

companies (company_id PK)
 └─1:N─ drives (company_id FK, ON DELETE CASCADE)
         ├─1:N─ drive_students        (drive_id FK CASCADE, student_id FK CASCADE)  -- current state
         ├─1:N─ drive_rounds          (drive_id FK CASCADE, PK(drive_id,round_no))  -- per-round date
         ├─1:N─ drive_round_history   (drive_id FK CASCADE, student_id FK CASCADE)  -- append-only audit
         └─1:1─ company_posts.drive_id (UNIQUE, ON DELETE CASCADE)                  -- optional announcement

students.assigned_spc_id ─> spc(spc_id) ON DELETE SET NULL
company_posts ─1:N─ company_post_attachments (post_id FK CASCADE)
notifications (user_id FK) -- shared by all roles, self-scoped
invitations (email UNIQUE, token UNIQUE) -- pending staff invites
applications -- LEGACY, see §5
```

**Observations**
- The `users` → `students`/`tpc`/`spc` split is clean. A user has exactly one role (`users.role`) and at most one profile row per type. SPC is a student who also has an `spc` row (dual identity — documented in [docs/AUTHORIZATION.md](../AUTHORIZATION.md)).
- **Department/branch are denormalized strings** (`students.department`, `tpc.department`, `spc.department`), not a reference table. The verification pipeline depends on exact string equality (`tpc.department = students.department`), enforced by the "Department of " prefix convention (migration 021/022). This is fragile — see [docs/INVARIANTS.md](../INVARIANTS.md) — but currently consistent. A future `departments`/`branches` reference table would remove the string-matching risk.
- `students.cgpa` is derived server-side from SPIs and never client-supplied; `is_profile_complete` is a **generated STORED column** (migration 022) — good, keeps the flag consistent with the data.

---

## 2. Foreign keys & cascade rules

| Child | Parent | On delete | Assessment |
|-------|--------|-----------|------------|
| `drives.company_id` | `companies` | CASCADE | Deleting a company deletes its drives (and, transitively, drive_students/history/rounds/announcement). Powerful — confirm admins understand a company delete wipes placement history. |
| `drive_students.drive_id` | `drives` | CASCADE | Correct. |
| `drive_students.student_id` | `students` | CASCADE | Deleting a student removes their drive participation. Acceptable, but see history note below. |
| `drive_round_history.drive_id/student_id` | drives/students | CASCADE | **Trade-off:** the "append-only permanent audit trail" is destroyed if the drive or student is deleted. For a true audit trail, consider `ON DELETE SET NULL` on `student_id` (retain the event) or soft-deletes. |
| `drive_rounds.drive_id` | `drives` | CASCADE | Correct. |
| `company_posts.drive_id` | `drives` | CASCADE | Correct (announcement is the child). |
| `company_post_attachments.post_id` | `company_posts` | CASCADE | Correct. |
| `students.assigned_spc_id` | `spc` | SET NULL | Correct — demoting/removing an SPC unassigns their students. |
| `students.user_id` | `users` | (plain ref, migration 022) | No explicit cascade; deleting a user with a student row would FK-error. Decide policy. |

### FK correctness bug

**`company_posts.posted_by UUID NOT NULL REFERENCES users(id) ON DELETE SET NULL`** ([013_create_company_posts.sql:11](../../server/src/migrations/013_create_company_posts.sql)) is self-contradictory: `ON DELETE SET NULL` will try to write NULL into a `NOT NULL` column when the posting user is deleted, raising an error and **blocking the user deletion**. Same latent issue anywhere a `NOT NULL` FK has `SET NULL`.
- **Fix:** either drop `NOT NULL` (allow orphaned posts with `posted_by = NULL`) or change to `ON DELETE CASCADE`/`RESTRICT` per intent. Given announcements should survive an admin leaving, `DROP NOT NULL` + keep `SET NULL` is the natural choice.

---

## 3. Indexes

### Existing (migration 004) — partly broken

```sql
CREATE INDEX idx_students_branch ON students(branch);           -- OK
CREATE INDEX idx_students_cgpa   ON students(cgpa);             -- OK
CREATE INDEX idx_companies_drive_date ON companies(drive_date); -- FAILS: companies has no drive_date column
CREATE INDEX idx_applications_student  ON applications(student_id);   -- legacy table, OK column
CREATE INDEX idx_applications_company  ON applications(company_id);   -- FAILS: applications has no company_id (only student_id, drive_id)
CREATE UNIQUE INDEX idx_unique_application ON applications(student_id, company_id); -- FAILS: same non-existent column
```
- **`idx_companies_drive_date` references a non-existent column** → the statement errors (`companies` has no `drive_date`).
- **`idx_applications_company` and `idx_unique_application` reference `applications.company_id`**, which does not exist — [003](../../server/src/migrations/003_create_applications.sql) defines `student_id` and `drive_id` only. Both statements fail. (Verified by direct read.)
- Together these mean **migration 004 cannot be applied as written** — at least three of its six statements error.

### Migration ordering defect (fresh replay fails even earlier)

Migration **003** creates `applications` with `drive_id INT NOT NULL REFERENCES drives(drive_id)`, but `drives` is not created until migration **010**. On a clean in-order replay, 003 aborts because `drives` does not yet exist. The live database only works because it was applied by hand out of strict order. This is concrete proof that **the migration set is not replayable from scratch** and reinforces the need for a runner + a generated `schema.sql` baseline (§6).

### `drive_round_history` (migration 026) — good
```sql
idx_drh_drive_round   ON drive_round_history(drive_id, round_no)
idx_drh_drive_student ON drive_round_history(drive_id, student_id)
```

### Missing indexes (hot query paths)

Every query below is a **sequential scan** today. Recommended additions:

| Index | Serves | Query evidence |
|-------|--------|----------------|
| `students(user_id)` — already UNIQUE, so covered | `getMyProfile`, `upsertMyProfile`, `my-drives`, `my-results` | [studentController.js:417](../../server/src/controllers/studentController.js) |
| `students(assigned_spc_id, review_status)` | SPC queue | [spcController.js:29](../../server/src/controllers/spcController.js) |
| `students(department, review_status)` | TPC queues | [tpcController.js:360](../../server/src/controllers/tpcController.js) |
| `students(department, branch)` | TPC lists / SPC assignment | [tpcController.js:326](../../server/src/controllers/tpcController.js) |
| `students(review_status)` partial `WHERE review_status='verified'` | eligibility engine | [driveController.js:26](../../server/src/controllers/driveController.js) |
| `drive_students(drive_id, status)` | round workflow selects | [driveController.js:141](../../server/src/controllers/driveController.js), many |
| `drive_students(student_id)` | `my-drives` join | [driveController.js:1196](../../server/src/controllers/driveController.js) |
| `company_posts(drive_id)` — already UNIQUE, covered | drive↔announcement join | [driveController.js:342](../../server/src/controllers/driveController.js) |
| `notifications(user_id, created_at DESC)` | notification list | [notificationController.js:56](../../server/src/controllers/notificationController.js) |

At current data volumes (hundreds–thousands of students) seq scans are tolerable, but these indexes are cheap insurance and required before the tables grow. Details and `EXPLAIN` guidance in [04-QUERY-PERFORMANCE.md](04-QUERY-PERFORMANCE.md).

### Duplicate / unused indexes
- No duplicate indexes found.
- `applications.*` indexes are unused (legacy table). Drop with the table.

---

## 4. Constraints & check constraints

Well-used and generally good:
- `drives.drive_state CHECK IN ('SHORTLISTING','ROUND_IN_PROGRESS','COMPLETED')` and `round_stage CHECK` (024).
- `drive_students.status CHECK IN (7 values)` and `attendance_mark CHECK` (025).
- `drive_round_history.stage/result CHECK` (026).
- `students.semester CHECK BETWEEN 5 AND 8` (018/022).
- `company_posts.post_type CHECK IN ('announcement')` after the email type was dropped (032).
- `UNIQUE(drive_id, student_id)` on drive_students; `UNIQUE(drive_id)` on company_posts.

**Gaps:**
- `students.review_status` has **no CHECK constraint** despite a fixed vocabulary (`pending`, `spc_verified`, `spc_rejected`, `verified`, `rejected`). Migration 035 had to repair `'approved'` values that a bulk import wrote — a CHECK would have prevented that. **Add** `CHECK (review_status IN (...))`.
- `students.placement_status` (`unplaced`/`placed`) has no CHECK.
- `users.role` has no CHECK (`student`/`spc`/`tpc`/`admin`).
- `drives.status` legacy column has a CHECK but is explicitly "never gate logic on status" (024) — consider dropping it to avoid confusion with `drive_state`.

---

## 5. Legacy `applications` table

`applications` ([003](../../server/src/migrations/003_create_applications.sql)) modeled a student-applies-to-drive flow that **no longer exists** — the product moved to admin-driven shortlisting (`drive_students`, migration 020) and migration 029 dropped `drives.drive_date`/`application_deadline`. `applications` is not referenced by any live controller.
- **Recommendation:** drop `applications` and its indexes in a new migration, after confirming no data must be retained. Keeping it invites confusion (the stale `audit/` docs built a whole "applications vs drive_students" narrative around it).

---

## 6. Migration hygiene

| Aspect | State |
|--------|-------|
| **Runner** | **None.** Migrations are applied by hand (see [memory: DB migrations applied manually]). The live DB can silently diverge from the files — migration 022 exists solely to reconcile a drifted instance. |
| **Numbering** | Contiguous 001–037 **except a duplicate `015`** (`015_create_notifications.sql` and `015_widen_student_branch.sql`). Files 027–034 were renamed to bare numbers (`027.sql`…`034.sql`); git shows the descriptive names as `D` (deleted) + the bare names untracked — content is preserved, only names churned. |
| **Reversibility** | **No down-migrations.** None of the 37 files has a rollback path. |
| **Determinism** | The later migrations (022, 024, 025, 026, 032, 035) are carefully **idempotent** (`ADD COLUMN IF NOT EXISTS`, `information_schema` guards, no-op UPDATEs) — genuinely good. The early ones (001–014) are plain `CREATE TABLE`/`CREATE INDEX` with no `IF NOT EXISTS`, so a re-run fails. |
| **Production safety** | 004 is broken (§3). 007 seeds a hardcoded credential ([01-VULNERABILITY-REPORT.md](01-VULNERABILITY-REPORT.md) VULN-05). Otherwise the mutating migrations wrap multi-statement changes appropriately (035 uses an explicit transaction). |

### Recommendations
1. **Adopt a migration runner** (`node-pg-migrate`, `dbmate`, or Knex) with a `schema_migrations` ledger so applied state is tracked and replay is deterministic. This is the single highest-leverage DB fix.
2. **Fix migration 004** (remove/replace the `companies(drive_date)` index; drop the bogus `applications` indexes) so a fresh DB can be built from the files.
3. **Resolve the duplicate 015** — renumber one to 015b/038 in the new runner's ledger.
4. **Add down-migrations** (or adopt a tool that expects them) so changes are reversible in production.
5. **Add the missing CHECK constraints** (§4) and the FK fix (§2) as new migrations.
6. **Produce a single `schema.sql` baseline** generated from a clean apply, so new environments don't replay 37 hand-edited files. Keep [schema.md](../../schema.md) as the human-readable companion.

---

## 7. Table growth & retention

- `drive_round_history` and `notifications` are append-only and will grow unbounded. Add a retention/archival policy (e.g. archive history for completed drives older than N years; delete read notifications older than 90 days).
- No `updated_at` triggers — `updated_at` is set manually in controllers (`drives`, `company_posts`). Consistent today; a trigger would make it tamper-proof.

Priorities and effort in [08-REMEDIATION-PLAN.md](08-REMEDIATION-PLAN.md).
