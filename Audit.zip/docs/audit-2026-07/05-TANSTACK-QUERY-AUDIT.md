# TanStack Query Audit

Client: React 18 + `@tanstack/react-query` v5. One shared `QueryClient` ([App.tsx:8](../../client/src/App.tsx)); hooks in `client/src/hooks/*`; keys centralized in [queryKeys.ts](../../client/src/hooks/queryKeys.ts); all network I/O goes through one Axios instance.

**Overall grade: good.** The data layer is one of the healthier parts of the codebase — a single client, a centralized key factory, consistent invalidation, and real optimistic updates in at least one place. The recommendations below are refinements, not rewrites.

---

## Global configuration

```ts
// App.tsx
new QueryClient({ defaultOptions: { queries: {
  refetchOnWindowFocus: false,
  staleTime: 30_000,
} } });
```

| Setting | Current | Assessment / recommendation |
|---------|---------|------------------------------|
| `staleTime` | 30 s global | Reasonable default. Consider raising for rarely-changing data (companies, branches) and lowering for the live drive workflow (see per-hook table). |
| `gcTime` | unset → default 5 min | Fine. No action. |
| `retry` | unset → default 3 | **Issue:** mutations and queries retry 3× on **every** error including 4xx. A failed `POST` that 400s will retry 3 times. Set a global `retry` that skips 4xx (the pattern `useProfile` already uses locally). |
| `refetchOnWindowFocus` | false | Intentional. Fine. |
| `refetchOnReconnect` | unset → default true | Fine. |
| `mutations` defaults | none | Add a global mutation `retry: false` (or 4xx-aware) so mutations never silently replay a write. |

**Recommended global default:**
```ts
queries: {
  refetchOnWindowFocus: false,
  staleTime: 30_000,
  retry: (count, err) => (err?.status >= 400 && err?.status < 500 ? false : count < 2),
},
mutations: { retry: false },
```

---

## Query keys

[queryKeys.ts](../../client/src/hooks/queryKeys.ts) is a clean, hierarchical factory (`["students","detail",id]`, `["drives",...]`, `["tpc",...]`). This is exactly the right pattern — it makes broad invalidation (`["tpc"]`) and precise invalidation (`["drives","detail",id]`) both safe from typos. **No changes needed.**

One subtlety: filter params are baked into keys (`tpcStudents(rollNo, year)`, `tpcQueue(branch, year)`). That is correct (different filters = different cache entries) but means each distinct filter combination is a separate fetch with no shared base — acceptable given the small result sets.

---

## Per-hook review

| Hook file | Queries / mutations | staleTime | retry | Invalidation | Notes |
|-----------|--------------------|-----------|-------|--------------|-------|
| `useProfile.ts` | profile read + create/update/upsert | global | custom (skips 4xx) | `profile`, `students()` | Good local retry policy — promote it to the global default. |
| `useDrives.ts` | 8 queries, ~12 mutations | global | global | `useDriveWorkflowInvalidator` → `drive(id)`, `driveStudents(id)`, `drives` | Well-factored shared invalidator. Detail queries correctly gated by `enabled: id !== undefined`. |
| `useVerification.ts` | SPC/TPC pipeline | global | global | broad `invalidateTpc` → whole `["tpc"]` subtree + `students()` | Coarse but correct — see below. |
| `useCompanyPosts.ts` | posts CRUD | global | global | posts + `drives` + `myDrives` (posts can be drive-linked) | Correct cross-invalidation. |
| `useNotifications.ts` | list + read/read-all/delete | global | global | optimistic `onMutate`/rollback/`onSettled` | **Best-practice example** — the model to copy. |
| `useInvitations.ts` | verify/complete | global | `retry: false` + `enabled` on token | — | Correct. |
| `useCompanies.ts`, `useStudents.ts` | CRUD | global | global | standard invalidation | Fine. |

---

## Findings & recommendations

### TQ-01 [Medium] Global `retry: 3` on 4xx and on mutations
Covered above. A 400/401/403/409 currently retries three times, tripling error latency and risking duplicate side effects on non-idempotent mutations. **Fix:** the global config shown above.

### TQ-02 [Low] Coarse `["tpc"]` invalidation
`useVerification.ts` invalidates the entire `["tpc"]` subtree after any single verify/reject/assign. Correct (never shows stale data) but over-fetches — one action refetches every TPC list (`students`, `queue`, `spcVerified`, `branches`, `spcs`). At current sizes this is fine. If the TPC dashboards feel heavy, narrow to the specific keys the action affects (e.g. verify → `tpcQueue` + `tpcSpcVerified` only). Keep the broad invalidation until it measurably hurts — correctness first.

### TQ-03 [Low] Imperative `refetch()` in AdminDashboard
[AdminDashboard.tsx:60-61](../../client/src/pages/admin/AdminDashboard.tsx) calls `students.refetch(); companies.refetch();` directly. Prefer invalidation via the mutation that changed the data, so the dashboard updates reactively without an imperative nudge. Minor.

### TQ-04 [Low] No prefetching / parallel-fetch orchestration
Detail pages fetch on mount (`enabled` gated). For known navigations (drive list → drive detail), `queryClient.prefetchQuery` on row hover/click would remove the detail-page spinner. Optional polish. The drive workflow pages already fetch drive + students + rounds in parallel (independent `useQuery` calls), so there is no serial waterfall there.

### TQ-05 [Low] No pagination / infinite queries
No `useInfiniteQuery` anywhere; list hooks fetch the full result set (mirrors the backend's lack of pagination, [04-QUERY-PERFORMANCE.md](04-QUERY-PERFORMANCE.md)). When the backend adds pagination, convert `useStudents` / notifications to `useInfiniteQuery` (or page-param `useQuery`). Coupled work — do the backend side first.

### TQ-06 [Low] Live workflow staleness
During an active drive, admins act on `drive_state`/`round_stage` that change every stage transition. The 30 s `staleTime` plus explicit post-mutation invalidation is sufficient (the invalidator refetches immediately after each transition). No polling needed. If multiple admins ever run the same drive concurrently, consider a shorter `staleTime` or `refetchInterval` on the active drive detail — not required today.

---

## Deduplication, batching, parallel fetching

- **Deduplication:** the shared client + shared `["students","me"]` key means dashboard/profile/complete-profile pages reuse one profile fetch instead of three — this is called out as an explicit design goal in [App.tsx:7](../../client/src/App.tsx) and works correctly.
- **Batching:** not applicable (REST, no GraphQL); the batching that matters is server-side (see the per-row loops in [04-QUERY-PERFORMANCE.md](04-QUERY-PERFORMANCE.md)).
- **Parallel fetching:** independent `useQuery` calls on the workflow pages fetch concurrently; no artificial serialization observed.

## Summary

| ID | Item | Priority | Effort |
|----|------|----------|--------|
| TQ-01 | 4xx-aware retry + `mutations.retry:false` | Medium | 0.25 d |
| TQ-02 | Narrow `["tpc"]` invalidation (only if needed) | Low | 0.5 d |
| TQ-03 | Replace imperative refetch with invalidation | Low | 0.1 d |
| TQ-04/05 | Prefetch + pagination (after backend) | Low | coupled |
