# Query Performance Review

Scope: every SQL statement in the live controllers. The app is not yet at a scale where these bite, but each item below is a latent scaling problem. Priorities: **P** (do before growth) / **L** (nice-to-have).

Data-volume assumption: hundreds–low-thousands of students, tens of drives, up to a few hundred `drive_students` per drive. All "expected improvement" figures are order-of-magnitude, not benchmarked.

---

## 1. `SELECT *` over-fetching

`SELECT *` appears at ~15 sites. Two matter for security/perf; the rest are hygiene.

### QP-01 [P] `login` selects the whole users row including `password_hash`
- **Evidence:** [authController.js:486](../../server/src/controllers/authController.js) — `SELECT * FROM users WHERE email = $1`.
- **Impact:** pulls `password_hash` into app memory on every login (needed for compare — but `SELECT id, email, password_hash, role, is_verified` is enough and avoids future columns leaking).
- **Fix:** `SELECT id, email, password_hash, role, is_verified FROM users WHERE email = $1`.

### QP-02 [P] `getStudents` returns the entire students table
- **Evidence:** [studentController.js:163](../../server/src/controllers/studentController.js) — `SELECT * FROM students ORDER BY id`, no `WHERE`, no `LIMIT`.
- **Impact:** every admin/TPC list load ships all ~40 columns for all students (marks, DOB, region, religion, URLs) over the wire. Combined with VULN-03 it is both a perf and a privacy problem. Grows linearly and unbounded.
- **Fix:** add pagination (`LIMIT/OFFSET` or keyset) and project only list columns:
  ```sql
  SELECT id, roll_no, name, email, branch, department, graduation_year,
         cgpa, placement_status, review_status
  FROM students
  WHERE ($1::text IS NULL OR department = $1)     -- scope for staff
  ORDER BY id
  LIMIT $2 OFFSET $3;
  ```
- **Expected improvement:** payload and scan cost drop from O(all students × all columns) to O(page size × list columns).

### QP-03 [L] Other `SELECT *` reads
`getDrives`, `getDriveById`, `getCompanies`, `getCompanyById`, `getPosts`, TPC queue, `getMyProfile`, `loadDriveForUpdate` etc. return full rows. Acceptable for single-row detail reads; for the **list** endpoints (`getDrives`, `getCompanies`, `getPosts`, TPC/SPC lists) project explicit columns + paginate. Low urgency at current scale.

---

## 2. Per-row loops inside transactions (bounded N+1)

These are **not** classic N+1 across HTTP requests — they run inside a single admin transaction — but they issue one round-trip per student and will dominate latency for large shortlists. All are set-based-rewritable.

### QP-04 [P] `confirmStudents` — one INSERT per student
- **Evidence:** [driveController.js:567](../../server/src/controllers/driveController.js) — `for (const studentId of studentIds) { INSERT ... }`.
- **Complexity:** O(N) round-trips for N shortlisted students.
- **Fix:** single multi-row insert via `UNNEST`:
  ```sql
  INSERT INTO drive_students (drive_id, student_id, status, current_round, added_by)
  SELECT $1, s, 'SHORTLISTED', -1, $3
  FROM UNNEST($2::bigint[]) AS s;
  ```
- **Improvement:** N round-trips → 1. For a 300-student shortlist, ~300× fewer queries.

### QP-05 [P] `startRoundZero` — one history INSERT per student
- **Evidence:** [driveController.js:684](../../server/src/controllers/driveController.js).
- **Fix:** set-based insert into `drive_round_history` selecting from `drive_students`:
  ```sql
  INSERT INTO drive_round_history (drive_id, student_id, round_no, stage, result, recorded_by)
  SELECT $1, student_id, 0, 'SHORTLIST', 'SHORTLISTED', $2
  FROM drive_students WHERE drive_id = $1;
  ```

### QP-06 [P] `finalizePrefilter` — SELECT-then-UPDATE per removed student
- **Evidence:** [driveController.js:766-773](../../server/src/controllers/driveController.js) loops `loadDriveStudent` then `UPDATE`.
- **Fix:** one `UPDATE ... FROM UNNEST(ids, reasons)` for the removals, then one set-based history insert. Guard idempotency with `WHERE status='ACTIVE'` in the UPDATE.

### QP-07 [P] `finalizeAttendance` / `completeDrive` — per-row UPDATE + history
- **Evidence:** [driveController.js:875](../../server/src/controllers/driveController.js), [:1067](../../server/src/controllers/driveController.js).
- **Fix:** batch the status UPDATEs and history inserts with set-based statements keyed off `drive_students` for the current round.

### QP-08 [P] `assignStudentsToSpc` — per-student UPDATE in round-robin
- **Evidence:** [tpcController.js:534](../../server/src/controllers/tpcController.js) — `for (i...) UPDATE students SET assigned_spc_id`.
- **Fix:** compute the round-robin assignment in JS (already done), then apply it in one statement using `UNNEST` of `(student_id, spc_id)` pairs:
  ```sql
  UPDATE students AS s SET assigned_spc_id = v.spc_id
  FROM UNNEST($1::bigint[], $2::int[]) AS v(student_id, spc_id)
  WHERE s.id = v.student_id;
  ```
- **Improvement:** O(students) round-trips → 1 per branch cohort.

> **Note:** correctness of these loops is fine (they run under `FOR UPDATE` locks in a transaction); the change is purely throughput. Keep the history semantics identical when rewriting.

---

## 3. Missing WHERE / unbounded reads (pagination)

**No endpoint paginates.** `getStudents`, `getCompanies`, `getDrives`, `getPosts`, `getMyNotifications`, TPC/SPC lists all return every matching row. Add a shared pagination convention (see [06-API-DESIGN.md](06-API-DESIGN.md)) and apply `LIMIT/OFFSET` (or keyset for large tables like notifications/history). [P] for `students`/`notifications`/`history`; [L] for the smaller tables.

---

## 4. Missing indexes for hot filters

Every filtered read below is a sequential scan. See [03-DATABASE-REVIEW.md §3](03-DATABASE-REVIEW.md) for the full list. Highest value:

| Query | Filter | Index to add |
|-------|--------|-------------|
| Eligibility engine ([driveController.js:11](../../server/src/controllers/driveController.js)) | `review_status='verified' AND cgpa>=? AND branch=ANY(...)` | `students(review_status)` partial, or `students(review_status, cgpa)` |
| SPC queue | `assigned_spc_id=? AND review_status='pending'` | `students(assigned_spc_id, review_status)` |
| TPC queues | `department=? AND review_status=?` | `students(department, review_status)` |
| Round workflow | `drive_id=? AND status=? AND current_round=?` | `drive_students(drive_id, status)` |
| Notifications | `user_id=? ORDER BY created_at DESC` | `notifications(user_id, created_at DESC)` |

**Verify with `EXPLAIN (ANALYZE, BUFFERS)`** on a seeded dataset before and after — at low volume the planner may still choose a seq scan, which is fine; add the indexes so the plan flips automatically as data grows.

---

## 5. Inefficient counts / aggregation

- No `COUNT(*)` over large tables in hot paths today. When pagination is added, avoid `SELECT COUNT(*)` on every page for `students`; use an approximate count (`reltuples` from `pg_class`) or return `hasNextPage` from a `LIMIT n+1` probe instead of a total.
- The eligibility "min CGPA throughout" predicate ([driveController.js:37-47](../../server/src/controllers/driveController.js)) is a per-row expression over 8 SPI columns; fine functionally, not indexable. If drives are created often against large cohorts, consider a materialized `min_recorded_spi` generated column to make it sargable. [L]

---

## 6. Repeated / redundant queries

- `getDriveLabel` ([driveController.js:124](../../server/src/controllers/driveController.js)) runs a `companies` lookup on every notification batch. Within a single workflow transaction it may be called once (fine). No cross-request duplication.
- The eligibility list is recomputed on create, update, and `GET /:driveId/eligible` — intentional (never persisted). Acceptable; it is the product's "always fresh" design.

---

## Priority summary

| ID | Item | Priority | Effort |
|----|------|----------|--------|
| QP-02 | Paginate + project `getStudents` | P | 0.5 d |
| QP-04–08 | Set-based rewrites of the 5 per-row loops | P | 1.5 d |
| §4 | Add hot-path indexes (new migration) | P | 0.5 d |
| QP-01 | Narrow `login` projection | P | 0.1 d |
| §3 | Pagination convention across list endpoints | P | 1 d |
| QP-03, §5, §6 | Remaining `SELECT *` / count tuning | L | 1 d |

Full sequencing in [08-REMEDIATION-PLAN.md](08-REMEDIATION-PLAN.md).
