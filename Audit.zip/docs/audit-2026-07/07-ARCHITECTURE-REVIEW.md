# Architecture Review

Covers backend structure, frontend structure, connection management, logging/monitoring, production hardening, and testing strategy.

---

## 1. Backend architecture

**Current shape:** `routes → middleware (auth/role/validate) → controllers → pg pool`. There is no service or repository layer — controllers hold both HTTP concerns and SQL. Shared logic lives in `lib/` (`cgpa.js`, `dbError.js`, `announcements.js`, `schema.js`).

**Strengths**
- Clear separation of routing, auth/role middleware, and Zod validators.
- Reusable helpers extracted where it counted: `lib/announcements.js` (`insertAnnouncement`/`replaceAttachments`, shared by drive + company-post controllers), `lib/cgpa.js` (single CGPA derivation), `lib/dbError.js` (SQLSTATE→HTTP mapping).
- Transaction discipline is genuinely good in `driveController` — `loadDriveForUpdate` + `FOR UPDATE` + in-transaction history appends.

**Problems**
| Issue | Evidence | Recommendation |
|-------|----------|----------------|
| **Oversized controller** | `driveController.js` = **1380 lines** covering CRUD, eligibility, shortlisting, 6 workflow transitions, history, dates, notifications. | Extract a `driveWorkflowService` (state transitions) and `eligibilityService` (the SQL in `getEligibleStudentsForDrive`). Keep the controller thin: parse → call service → shape response. |
| **Mixed concerns** | Controllers build SQL, enforce business rules, and shape HTTP responses in one function. | Introduce a light repository layer (`repositories/*.js`) returning plain data, and services for multi-step rules. Do this incrementally, highest-churn files first (`drive`, `tpc`, `student`). |
| **Dead code** | ~300 commented-out lines (the entire old auth implementation) at the top of `authController.js`; commented OLD blocks in `verifyEmail`. | Delete. Version control is the history. |
| **Duplicated update logic** | `updateStudent` and `upsertMyProfile` both hand-roll a giant column list + review-flag logic. | Share a `buildStudentUpdate` helper; both already agree on `ignoredFields`/`REVIEW_IGNORED_FIELDS`. |
| **Notifications as a controller** | `notificationController` exports internal helpers (`createNotification`, `createNotificationForRole`) imported by other controllers — a service masquerading as a controller. | Move the internal helpers to `services/notificationService.js`; keep the HTTP handlers in the controller. |
| **No circular deps** observed | — | Maintain by putting shared helpers in `lib/`/`services/`, never controller→controller. (Currently `driveController` imports from `lib/announcements`, not from `companyPostController` — good.) |

**Target layering (incremental):**
```
routes/         HTTP surface + middleware chain
controllers/    parse req → call service → res.json (thin)
services/       business rules, transactions, multi-step workflows
repositories/   SQL per table, returns plain rows
lib/            pure helpers (cgpa, dbError, validation schemas)
middleware/     auth, role, validation, (new) error handler, request-id
```

---

## 2. Frontend architecture

**Current shape:** Vite + React Router 7, `pages/{auth,student,spc,tpc,admin}`, `components/{ui,dashboard}`, `hooks/`, `services/`, `context/AuthContext`, `lib/`. ~119 files, ~13.2k lines.

**Strengths**
- Consistent single-axios service layer; centralized query keys; centralized validation (`lib/validation.ts`).
- Good component reuse: `StudentVerificationDetailPage` shared across SPC/TPC/admin via props; shared `data-table/` wrapper, filters, `states.tsx` (loading/empty/error).
- Zero `console.*` in `src`; strict-mode TS with a typecheck-gated build.
- Loading/error/empty states are componentized (`components/dashboard/states.tsx`).

**Problems**
| Issue | Evidence | Recommendation |
|-------|----------|----------------|
| **Oversized pages** | `admin/DriveStudentsPage.tsx` = **991 lines**, `admin/DrivesPage.tsx` = **777**, `student/CompleteProfilePage.tsx` = **513**. | Split the drive pages: extract the round-workflow panel, the roster table, and the dialogs into `components/dashboard/drive/*`. The workflow state machine UI is the bulk — isolate it. |
| **No form library** | Manual `useState` + `lib/validation.ts` across large forms. | Optional: adopt `react-hook-form` + a shared Zod schema (reused client+server) to cut the hand-rolled state and unify validation. Medium effort, high consistency payoff. |
| **Memoization** | Large tables re-render on parent state changes. | Profile with React DevTools; memoize row components and stable callbacks in the big admin tables where re-renders are visible. Don't pre-optimize elsewhere. |
| **No lint** | No ESLint/Prettier. | Add `eslint` + `@typescript-eslint` + `eslint-plugin-react-hooks` (catches missing deps/exhaustive-deps) and Prettier; wire a `lint` script and CI gate. |
| **TS strictness** | `strict:true` but `noUnusedLocals`/`noUnusedParameters`/`noFallthroughCasesInSwitch` unset. | Enable them to catch dead code at build time. |

**Accessibility:** shadcn/Radix primitives bring keyboard/focus/ARIA for free. Preserve it by not replacing them with custom controls (a stated project rule in `CLAUDE.md`). Audit the big custom tables for header/scope and focus order.

---

## 3. Connection management

**Current:** `new Pool({ connectionString })` only ([config/db.js:8](../../server/src/config/db.js)). No `max`, `idleTimeoutMillis`, `connectionTimeoutMillis`, `statement_timeout`, or SSL. No graceful shutdown; the process just `app.listen`s.

**Risks**
- Default pool `max` is 10. A few slow queries (unindexed seq scans, [04](04-QUERY-PERFORMANCE.md)) can saturate it and stall all requests.
- No `statement_timeout` → a runaway query holds a connection indefinitely.
- No SSL config → depends entirely on `DATABASE_URL` including `sslmode`; make it explicit for managed Postgres.
- No `pool.end()` on shutdown → connections may be dropped mid-query on deploy/restart.

**Recommendation**
```js
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: Number(process.env.PG_POOL_MAX ?? 10),
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,
  statement_timeout: 10_000,           // cap any single query
  ssl: process.env.PGSSL === 'require' ? { rejectUnauthorized: true } : undefined,
});
process.on('SIGTERM', async () => { await pool.end(); process.exit(0); });
```
**Transactions:** already correct — every multi-step mutation uses `pool.connect()` + `BEGIN`/`COMMIT`/`ROLLBACK` in `try/finally` with `client.release()`. No connection leaks found (every `connect()` has a matching `release()` in `finally`). **Prepared statements:** `pg` parameterized queries are used throughout (not named prepared statements, but parameterized — safe and fine).

---

## 4. Logging & monitoring

**Current:** `morgan('dev')` for request logs; ~110 ad-hoc `console.*` calls; no request ids, no structured logs, no metrics, no health endpoint.

**Recommendations**
- **Structured logging:** replace `console.*` with `pino` (JSON logs, levels, redaction of PII fields — see VULN-18). Wrap with `pino-http` for request logging (replaces morgan) and attach a **request id** (`req.id`) to every log line and error response.
- **Health & readiness:** add `GET /healthz` (process up) and `GET /readyz` (runs `SELECT 1` against the pool). Required by most orchestrators/load balancers.
- **Audit & security logs:** log auth events (login success/failure, role changes, verification decisions) and admin destructive actions to a dedicated audit stream. The `drive_round_history` table is already a domain audit log — extend the concept to auth/role changes.
- **Metrics / tracing:** for production scale, add OpenTelemetry (HTTP + `pg` auto-instrumentation) exporting to your APM, plus basic RED metrics (rate/errors/duration) per route. Defer until there is somewhere to send them.

---

## 5. Production hardening checklist

| Control | Present? | Action |
|---------|----------|--------|
| `helmet` (security headers) | ❌ | Add `app.use(helmet())`. |
| HTTPS/HSTS | ❌ (assumed at proxy) | Terminate TLS at the proxy; set HSTS via helmet. |
| Rate limiting | ❌ | `express-rate-limit` on `/auth/*` (tight) + global (loose). |
| CORS allow-list | ❌ (open) | `cors({ origin: FRONTEND_URL, credentials: true })`. |
| Body-size limit | ❌ (implicit 100 kb) | `express.json({ limit: '1mb' })`. |
| Compression | ❌ | `compression()`. |
| Request timeouts | ❌ | server + `statement_timeout` (above). |
| Central error handler / 404 | ❌ | Add both. |
| Graceful shutdown | ❌ | `SIGTERM` → `pool.end()`. |
| Cache headers | ❌ | Set `Cache-Control: no-store` on authed JSON; long cache on hashed static assets (proxy). |
| Secrets management | ⚠️ | Move `google-drive-key.json` out of tree (VULN-06); env via secret store. |
| Env validation | ❌ | Validate required env at boot (Zod) — fail fast if `JWT_ACCESS_SECRET`/`DATABASE_URL` missing. |

---

## 6. Testing strategy

**Current: zero automated tests.** Build script runs `tsc --noEmit` (client) / `node --check` only. No test runner, no CI.

Recommended pyramid, risk-ranked to the findings in this audit:

| Layer | Priority | What to cover first |
|-------|----------|---------------------|
| **API / integration** (supertest + a test Postgres) | **P0** | Authorization matrix — one test per endpoint asserting the *right* roles pass and the *wrong* ones get 403 (this is the regression net for VULN-01–04). Verification pipeline transitions. Drive workflow state machine (each transition's guard). |
| **Unit** (vitest/jest) | P1 | `lib/cgpa.js` (derivation + edge cases), `lib/dbError.js`, eligibility predicate, review-flag logic. Pure functions, cheap, high value. |
| **Migration** | P1 | Apply all migrations to a fresh DB in CI and assert the final schema matches `schema.md`. This would have caught the 003/004 ordering/column defects ([03](03-DATABASE-REVIEW.md)). |
| **Frontend component** (vitest + Testing Library) | P2 | The big workflow pages, the verification detail, form validation paths. |
| **E2E** (Playwright) | P2 | The three critical journeys: student completes profile → verified; admin creates drive → shortlist → rounds → placement; invite → staff onboarding. |
| **Security** | P2 | Automate the authz tests above + add `npm audit`/dependency scanning to CI (would flag the `xlsx` issue, VULN-16). |
| **Performance** | P3 | Seed a realistic dataset; `EXPLAIN ANALYZE` the hot queries pre/post-index ([04](04-QUERY-PERFORMANCE.md)); a k6 smoke test on list endpoints once paginated. |

**First move:** stand up a CI pipeline (GitHub Actions) that runs typecheck + lint + the API authz tests against an ephemeral Postgres. That single pipeline turns the biggest risks (silent authz regressions, unreplayable migrations) into build failures.

Effort and sequencing: [08-REMEDIATION-PLAN.md](08-REMEDIATION-PLAN.md).
