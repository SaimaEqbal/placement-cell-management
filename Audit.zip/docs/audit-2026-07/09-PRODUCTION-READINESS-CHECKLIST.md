# Production Readiness Checklist

Sign-off checklist. `[ ]` = not done, `[~]` = partial, `[x]` = done. Status reflects the tree at audit time (2026-07-15). Reference the finding IDs in the other files for detail.

## Security
- [ ] `POST /students` role-guarded (VULN-01)
- [ ] Drive shortlist/history endpoints staff-only (VULN-02)
- [ ] SPC student reads scoped to assigned students (VULN-03)
- [ ] `PUT`/`DELETE /students/:id` scoped or admin-only (VULN-04)
- [ ] Hardcoded admin credential removed from seed (VULN-05)
- [ ] Service-account credential moved out of repo tree (VULN-06)
- [ ] `signup` no longer leaks `error.message` (VULN-07)
- [ ] Role checks ordered before body validation everywhere (VULN, [06](06-API-DESIGN.md))
- [ ] Document URL fields validated (`.url()` + https) (VULN-14)
- [x] SQL injection — all queries parameterized (verified)
- [x] No secrets in frontend bundle / no source maps in prod (verified)
- [x] `.env` / credentials never committed to git (verified)
- [x] Stack traces not returned to clients (verified, except VULN-07)

## Authentication & session
- [~] Passwords bcrypt-hashed (yes; cost inconsistent, VULN-10)
- [ ] Access-token lifetime shortened + refresh/rotation or revocation (VULN-08)
- [ ] Reset tokens single-use (VULN-09)
- [x] `forgot-password` non-enumerating (verified)
- [x] Role reloaded from DB each request (verified)

## Authorization
- [x] Every endpoint authenticated (except public auth/invite-completion, by design)
- [~] Role checks present (all except VULN-01)
- [~] Ownership/department scoping (correct for verification pipeline; gaps VULN-02/03/04/15)
- [x] Authorization matrix documented ([02](02-AUTHORIZATION-MATRIX.md), 67 endpoints)

## Platform hardening
- [ ] `helmet` / security headers
- [ ] CORS allow-list (currently open) (VULN-11)
- [ ] Rate limiting on `/auth/*` (VULN-12)
- [ ] Request body-size limit
- [ ] Compression
- [ ] Central error handler + 404 handler
- [ ] Graceful shutdown (`SIGTERM` → `pool.end()`)
- [ ] Env validation at boot

## Database
- [ ] Migration runner + tracked `schema_migrations` ([03](03-DATABASE-REVIEW.md))
- [ ] Migration 004 / 003-ordering defects fixed (fresh replay works)
- [ ] Duplicate `015` resolved
- [ ] `company_posts.posted_by` FK contradiction fixed
- [ ] CHECK constraints on `review_status`/`placement_status`/`role`
- [ ] Hot-path indexes added ([04](04-QUERY-PERFORMANCE.md))
- [ ] Legacy `applications` table dropped
- [ ] Retention policy for history/notifications
- [x] Transactions use `FOR UPDATE` + rollback discipline (verified)

## Connection management
- [ ] Pool `max` / idle / connection / statement timeouts set
- [ ] SSL config explicit
- [x] No connection leaks (every `connect()` has `release()` in `finally`, verified)

## Query performance
- [ ] Pagination on `students`/`notifications`/`history`
- [ ] Set-based rewrites of per-row loops (QP-04–08)
- [ ] `SELECT *` narrowed on list + login (QP-01/02)

## Frontend / data layer
- [ ] 4xx-aware retry + `mutations.retry:false` (TQ-01)
- [x] Single shared QueryClient + centralized query keys (verified)
- [x] Optimistic updates where it matters (notifications, verified)
- [ ] Oversized pages split
- [ ] ESLint/Prettier configured
- [x] Strict-mode TS, typecheck-gated build (verified)

## Observability
- [ ] Structured logging (`pino`) + PII redaction (VULN-18)
- [ ] Request ids
- [ ] `GET /healthz` + `GET /readyz`
- [ ] Auth/role audit logging
- [ ] Metrics / tracing (OpenTelemetry) — defer until APM target exists

## Testing & CI
- [ ] CI pipeline (typecheck + lint + tests)
- [ ] API authorization integration tests (regression net for Phase 0)
- [ ] Migration-replay test
- [ ] Unit tests (cgpa, eligibility, dbError)
- [ ] E2E for the 3 critical journeys
- [ ] Dependency scanning in CI (would flag VULN-16)

## Documentation
- [x] Audit report ([docs/audit-2026-07/](.))
- [x] Living architecture docs ([docs/](../))
- [ ] Deployment runbook validated against a real deploy
- [~] Root README (stub; pointer to docs added)

---

**Gate for production:** all **Security**, **Platform hardening**, and the **CI + authz tests** rows checked (= Phase 0 + Phase 1 in [08-REMEDIATION-PLAN.md](08-REMEDIATION-PLAN.md)). Database replayability (migration runner) should land before the first schema change made under production load.
