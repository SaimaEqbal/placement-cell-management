# API Design Review

REST over Express 5, JSON in/out, mounted under `/api` ([routes/index.js](../../server/src/routes/index.js)). Auth via `Authorization: Bearer <jwt>`.

---

## 1. REST consistency

Broadly consistent resource-oriented routing, with a few rough edges.

**Good:**
- Plural-ish resource collections with id params: `/students`, `/companies`, `/drive/:driveId`, `/company-post/:postId`, `/notifications/:id`.
- Correct verb usage: `GET` reads, `POST` creates, `PUT` full updates, `PATCH` partial (attendance, round date, notification read), `DELETE` removes.
- Self-scoped sub-resources are clearly named: `/students/me`, `/drive/my-drives`, `/drive/:driveId/my-results`.
- Workflow transitions as `POST` sub-actions (`/drive/:id/start-round-0`, `/finalize-prefilter`, `/advance-round`, `/complete`) — a reasonable RPC-over-REST choice for a state machine.

**Inconsistencies to fix (Low unless noted):**
1. **Singular vs plural collections.** `/drive` (singular) vs `/students`, `/companies`, `/notifications` (plural), and `/company-post` (singular, hyphenated) vs `companyPosts` in the client keys. Standardize on plural nouns (`/drives`, `/company-posts`). Requires coordinated client+server change; do it once.
2. **Nested resource under the wrong parent.** `/invite/invite` and `/invite/users/:userId/role` — the double "invite" and the `users` sub-path under `/invite` are awkward. Consider `/invitations` (collection) and `/users/:id/role` (a users resource).
3. **Mixed id param names.** `:id` (students, companies), `:driveId`, `:postId`, `:studentId`, `:tpcId`, `:notificationId`. Harmless but pick a convention (either always `:id` within a resource router, or always `:resourceId`).

---

## 2. Response shapes

**Inconsistent** — the biggest API-design issue. Three different envelopes are in use:

| Pattern | Example |
|---------|---------|
| Bare resource | `getStudentById` → `res.json(student)` |
| Bare array | `getStudents` → `res.json(rows)` |
| Wrapped object | `createDrive` → `res.json({ drive, eligibleStudents, announcement })` |
| Message-only | `deleteStudent` → `res.json({ message: "..." })` |
| Message + resource | `updateTPC` → `res.json({ message, tpc })` |

**Recommendation:** adopt one envelope for the whole API, e.g.
```json
{ "data": <resource|array>, "meta": { "pagination": {...} } }   // success
{ "error": { "message": "...", "code": "...", "fieldErrors": {...} } }  // failure
```
The client already normalizes errors in [axiosInstance.ts](../../client/src/api/axiosInstance.ts) (mapping Zod `fieldErrors`), so aligning the success shape is the missing half. This is a coordinated change; schedule it deliberately rather than piecemeal.

---

## 3. Pagination, filtering, sorting

- **Pagination: absent everywhere** (see [04-QUERY-PERFORMANCE.md](04-QUERY-PERFORMANCE.md)). Define one convention: `?page=&pageSize=` (or `?limit=&cursor=` keyset for large tables) returning `meta.pagination { page, pageSize, total|hasNext }`. Apply to `students`, `notifications`, `drive_round_history`, `company-posts` first.
- **Filtering: partial and ad-hoc.** TPC endpoints accept `?rollNo=`, `?branch=`, `?year=` (parsed with a local `parseYear`); most others accept nothing. Standardize query-param filtering and validate all filters through Zod (some are currently parsed by hand).
- **Sorting: hardcoded.** Each list has a fixed `ORDER BY` (students by id, drives by `created_at DESC`, etc.). Expose `?sort=` only where the UI needs it; otherwise leave the sensible defaults.

---

## 4. Validation

- **Zod throughout** ([lib/schema.js](../../server/src/lib/schema.js), 446 lines) via `*Middleware.js` validators — a real strength. Create/update/self-profile/TPC/company/drive/round/company-post schemas all exist.
- `updateDriveSchema` uses `.strict()` (rejects unknown keys); most others rely on Zod stripping unknown keys, described as intentional (guards against `cgpa` injection). Consider `.strict()` more widely so unexpected fields are surfaced as 400s rather than silently dropped.
- **Gaps:** document URL fields are `z.string()` not `.url()` (VULN-14); some query params (`year`, `round`) are parsed manually rather than via Zod. Move query-param parsing into Zod schemas for consistency.
- **Ordering bug:** in `company-post` routes the validator runs before `requireAdmin` ([companyPostRoutes.js:24](../../server/src/routes/companyPostRoutes.js)), leaking validation detail to non-admins. Put role checks before body validation everywhere.

---

## 5. Error handling & status codes

**Status codes are mostly correct:** 200/201 success, 400 validation, 401 unauth, 403 role/verify, 404 not-found, 409 conflict/state, 500 server. Good use of 409 for state-machine violations (locked drive, wrong stage) and unique-constraint conflicts.

**Issues:**
- **No central error handler** — each controller try/catches individually. A thrown error outside a try/catch has no safety net (crashes the process). Add Express error middleware ([12](../../docs/audit-2026-07/07-ARCHITECTURE-REVIEW.md)).
- `signup` leaks `error.message` (VULN-07); every other controller returns generic messages via `lib/dbError.js` — align it.
- DB errors are mapped through `pgErrorResponse` (`lib/dbError.js`) into `{ status, message }` — a good centralization; extend that pattern into the error middleware so controllers can simply `throw`/`next(err)` instead of repeating try/catch blocks.
- **No request id** on error responses; add one (see logging in [07](07-ARCHITECTURE-REVIEW.md)) so users can quote it in support.

---

## 6. Recommendations (prioritized)

| Item | Priority | Effort |
|------|----------|--------|
| Role-check-before-validation ordering fix | P (security-adjacent) | 0.1 d |
| Central error handler + `next(err)` pattern | P | 0.5 d |
| Pagination convention on hot list endpoints | P | 1 d (with [04](04-QUERY-PERFORMANCE.md)) |
| One success/error envelope | P1 | 1–2 d (coordinated client+server) |
| Zod-validate all query params; `.strict()` schemas | P1 | 0.5 d |
| Resource-name/id-param consistency (`/drives`, `/company-posts`) | P2 | 1 d (coordinated) |

Full sequencing in [08-REMEDIATION-PLAN.md](08-REMEDIATION-PLAN.md).
