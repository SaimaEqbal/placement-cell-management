# Remediation Plan

Phased, prioritized, with per-item effort estimates (developer-days, one mid-level engineer). Effort is implementation + tests + review, not calendar time. IDs reference [01-VULNERABILITY-REPORT.md](01-VULNERABILITY-REPORT.md), [03](03-DATABASE-REVIEW.md), [04](04-QUERY-PERFORMANCE.md), [05](05-TANSTACK-QUERY-AUDIT.md), [06](06-API-DESIGN.md), [07](07-ARCHITECTURE-REVIEW.md).

> **These are recommendations for an implementer, with identified caveats — not changes made in this audit.** Verify each `file:line` against the current tree before editing; the codebase is under active development.

---

## Phase 0 — Security blockers (do before ANY deployment)
**Goal:** close exploitable access-control and credential defects. **Total ≈ 2.5 d.**

| # | Fix | Files | Caveat | Effort |
|---|-----|-------|--------|--------|
| P0-1 | Add `requireAdminTPC` to `POST /students` (VULN-01) | [studentRoutes.js:29](../../server/src/routes/studentRoutes.js) | Confirm no legitimate client flow uses the open POST (students use `PUT /me`). | 0.25 d |
| P0-2 | Restrict `GET /drive/:id/students` & `/history` to staff (VULN-02) | [driveRoutes.js:50](../../server/src/routes/driveRoutes.js), [:83](../../server/src/routes/driveRoutes.js) | Verify the student UI only calls `my-drives`/`my-results`, not these. Grep the client services. | 0.25 d |
| P0-3 | Remove SPC from `GET /students` & `/students/:id`; keep SPC on its scoped queue (VULN-03) | [studentRoutes.js:28](../../server/src/routes/studentRoutes.js), [:32](../../server/src/routes/studentRoutes.js) | If any SPC screen opens a student detail, add an `assigned_spc_id`-scoped endpoint instead. Check `spcService`/SPC pages. | 0.5 d |
| P0-4 | Remove the hardcoded-credential seed (VULN-05); provision first admin via env-driven script or invite | [007_insert_admin.sql](../../server/src/migrations/007_insert_admin.sql) | Ensure a real admin exists in each environment before deleting the seed path. | 0.5 d |
| P0-5 | Scope or admin-restrict `PUT`/`DELETE /students/:id` (VULN-04) | [studentRoutes.js:34-35](../../server/src/routes/studentRoutes.js) | Decide department-scoped vs admin-only; match the verify/reject scoping convention. | 0.5 d |
| P0-6 | Fix role-check-before-validation ordering (company-post routes) | [companyPostRoutes.js:24](../../server/src/routes/companyPostRoutes.js) | Trivial reorder. | 0.1 d |
| P0-7 | Stop `signup` leaking `error.message` (VULN-07) | [authController.js:369](../../server/src/controllers/authController.js) | — | 0.1 d |

**Exit criterion:** an integration test asserts every endpoint rejects the wrong roles (see P1-7).

---

## Phase 1 — Platform hardening (before public traffic)
**Goal:** baseline production safety. **Total ≈ 3.5 d.**

| # | Fix | Detail | Caveat | Effort |
|---|-----|--------|--------|--------|
| P1-1 | `helmet`, CORS allow-list, body limit, compression (VULN-11, VULN-12) | `helmet()`, `cors({origin:FRONTEND_URL,credentials:true})`, `express.json({limit:'1mb'})`, `compression()` | CORS allow-list must include every real frontend origin (dev + prod). | 0.5 d |
| P1-2 | Rate limiting on `/auth/*` + global (VULN-12) | `express-rate-limit`; tight on login/forgot/resend | Tune limits to real usage; exempt health checks. | 0.5 d |
| P1-3 | Central error handler + 404 handler (VULN-12, [06](06-API-DESIGN.md)) | Final `(err,req,res,next)` returns generic msg + request id | Refactor controllers to `next(err)` gradually; the handler works immediately. | 0.5 d |
| P1-4 | Connection pool limits + `statement_timeout` + graceful shutdown ([07](07-ARCHITECTURE-REVIEW.md) §3) | `max`, timeouts, SSL, `SIGTERM→pool.end()` | Set `statement_timeout` high enough for the biggest legit workflow txn. | 0.5 d |
| P1-5 | Shorten access token + add refresh/rotation OR token-version revocation (VULN-08) | 15–60 min access + refresh table, or `token_version` column checked in `auth` | Bigger change; the token-version approach is smaller and enables logout/reset invalidation. Coordinate with client (silent refresh or re-login UX). | 1 d |
| P1-6 | Reset-token single-use + bcrypt cost consistency (VULN-09, VULN-10) | `password_changed_at`/used-token tracking; shared `hashPassword(cost=12)` | Ties into P1-5's token-version if done together. | 0.25 d |
| P1-7 | CI pipeline: typecheck + lint + API authz integration tests ([07](07-ARCHITECTURE-REVIEW.md) §6) | GitHub Actions + ephemeral Postgres + supertest | The authz test suite is the regression net for Phase 0. | 1 d (setup) |
| P1-8 | Env validation at boot | Zod-validate required env; fail fast | — | 0.25 d |
| P1-9 | Move `google-drive-key.json` out of tree; remove unused deps (VULN-06, VULN-17) | Secret store / env path; `npm uninstall crypto postgres @supabase/supabase-js resend` | Confirm `deferred/` isn't in the prod build before removing `googleapis`/`multer`. | 0.25 d |
| P1-10 | Replace/relocate `xlsx` (VULN-16) | Server-side export or `exceljs`/CSV | If kept, pin and only feed app-generated data. | 0.5 d |

---

## Phase 2 — Database & query correctness/performance
**Goal:** replayable migrations, right constraints, indexed hot paths. **Total ≈ 4 d.**

| # | Fix | Detail | Caveat | Effort |
|---|-----|--------|--------|--------|
| P2-1 | Adopt a migration runner + `schema_migrations` ledger ([03](03-DATABASE-REVIEW.md) §6) | `node-pg-migrate`/`dbmate`/Knex; generate a `schema.sql` baseline | Reconcile against the live DB first (migration 022 shows the drift). Don't auto-run destructive down-migrations in prod. | 1.5 d |
| P2-2 | Fix migration 004 & the 003/010 ordering defect ([03](03-DATABASE-REVIEW.md) §3) | Drop the `companies(drive_date)` and `applications.company_id` indexes; reorder or drop `applications` | Verify no data in `applications` must be kept before dropping. | 0.5 d |
| P2-3 | Fix `company_posts.posted_by` NOT NULL + SET NULL contradiction (VULN/DB) | `DROP NOT NULL` (keep SET NULL) or change cascade | Choose per intent (announcements survive user deletion → drop NOT NULL). | 0.25 d |
| P2-4 | Add missing CHECK constraints ([03](03-DATABASE-REVIEW.md) §4) | `review_status`, `placement_status`, `users.role` | Backfill/repair any out-of-vocabulary rows first (see migration 035 precedent). | 0.5 d |
| P2-5 | Add hot-path indexes ([04](04-QUERY-PERFORMANCE.md) §4) | new migration with the 5–6 indexes | Use `CREATE INDEX CONCURRENTLY` in prod to avoid locks. | 0.5 d |
| P2-6 | Set-based rewrites of the 5 per-row loops (QP-04–08) | `UNNEST`-based batch inserts/updates | Preserve history semantics exactly; add tests asserting identical `drive_round_history` output. | 1.5 d |
| P2-7 | Paginate + project `getStudents`; narrow `login` projection (QP-01, QP-02) | `LIMIT/OFFSET` + column list | Coordinate with client (pagination controls already exist as shared components). | 0.75 d |

*(P2 items overlap; the ~4 d total accounts for shared setup.)*

---

## Phase 3 — Architecture, API polish, docs, deeper testing
**Goal:** maintainability and long-term health. **Total ≈ 2–3 weeks.**

| # | Fix | Effort |
|---|-----|--------|
| P3-1 | Extract service/repository layer; slim `driveController` (1380→thin); move notification helpers to a service ([07](07-ARCHITECTURE-REVIEW.md) §1) | 4 d |
| P3-2 | Delete dead code (authController comments) + enable `noUnusedLocals`/`noUnused​Parameters` | 0.5 d |
| P3-3 | Split oversized frontend pages (`DriveStudentsPage` 991, `DrivesPage` 777) | 3 d |
| P3-4 | One API response envelope + Zod query-param validation + resource-name consistency ([06](06-API-DESIGN.md)) | 3 d (coordinated) |
| P3-5 | ESLint/Prettier + TanStack retry policy (TQ-01) + narrow invalidation (TQ-02) | 1.5 d |
| P3-6 | Structured logging (`pino`), request ids, health/readiness endpoints, audit log for auth/role ([07](07-ARCHITECTURE-REVIEW.md) §4) | 2 d |
| P3-7 | Test pyramid: unit (cgpa/eligibility), migration replay, component, E2E, dependency scanning ([07](07-ARCHITECTURE-REVIEW.md) §6) | 5–7 d |
| P3-8 | Retention policy for `drive_round_history` / `notifications`; drop legacy `applications` | 1 d |
| P3-9 | OpenTelemetry + metrics (when an APM target exists) | 2 d |

---

## Effort roll-up

| Phase | Scope | Effort |
|-------|-------|--------|
| **P0** | Security blockers | ~2.5 d |
| **P1** | Platform hardening | ~3.5 d |
| **P0+P1** | **Minimum production-safe** | **~6 d** (≈ 6–9 d with review/QA buffer) |
| P2 | DB & query | ~4 d |
| P3 | Architecture / polish / testing | ~2–3 weeks |
| **All** | **Mature posture** | **~5–7 developer-weeks** |

## Suggested sequencing
1. **Week 1:** P0 (all) + P1-1/2/3/4/8/9 + stand up P1-7 CI with the authz tests. Ship to a locked-down staging.
2. **Week 2:** P1-5/6/10 + P2-1/2/3 (migration runner + fixes). Re-run authz + migration-replay tests.
3. **Weeks 3–4:** P2-4/5/6/7 (constraints, indexes, batch rewrites, pagination).
4. **Weeks 5+:** P3 as capacity allows, service extraction and testing first.
