# Authorization Matrix

Every registered route, its middleware chain, the roles that can reach it, the scoping actually enforced in the controller, and any issue. Mounted prefixes are in [routes/index.js](../../server/src/routes/index.js). All routes are under `/api`.

**Legend**
- **Auth**: `auth` = valid JWT required · `public` = no auth.
- **Roles**: which roles pass the role middleware (`admin`/`tpc`/`spc`/`student`, or *any* authenticated).
- **Scope**: ownership/department/branch narrowing enforced in the controller (not just the role gate).
- Issue IDs reference [01-VULNERABILITY-REPORT.md](01-VULNERABILITY-REPORT.md).

---

## `/api/auth` — [authRoutes.js](../../server/src/routes/authRoutes.js)

| Route | Auth | Roles | Scope | Issues |
|-------|------|-------|-------|--------|
| `POST /auth/signup` | public | — | creates unverified user | No rate limit (VULN-12); leaks `error.message` (VULN-07) |
| `GET /auth/verify-email` | public | — | token (`purpose=email_verification`) | OK |
| `POST /auth/login` | public | — | credential check, `is_verified` gate | No rate limit → credential stuffing (VULN-12); 7-day token (VULN-08); `SELECT *` pulls `password_hash` (perf note) |
| `POST /auth/resend-verification` | public | — | by email | No rate limit (VULN-12) |
| `POST /auth/forgot-password` | public | — | non-enumerating | No rate limit → email bombing (VULN-12) |
| `POST /auth/reset-password` | public | — | token (`purpose=password_reset`) | Token replayable within 15 min (VULN-09) |

## `/api/students` — [studentRoutes.js](../../server/src/routes/studentRoutes.js)

| Route | Auth | Roles | Scope | Issues |
|-------|------|-------|-------|--------|
| `GET /students/me` | auth | any | self (`user_id = req.user`) | OK |
| `PUT /students/me` | auth | any | self; allowlisted columns; CGPA server-derived | OK (good design) |
| `GET /students` | auth | admin, tpc, spc | **none** — full table `SELECT *` | **SPC over-reach (VULN-03)**; no dept scope (VULN-15); no pagination |
| `POST /students` | auth | **any** | none | **No role guard (VULN-01, Critical)** |
| `GET /students/:id` | auth | admin, tpc, spc | none | **SPC over-reach (VULN-03)**; no dept scope (VULN-15) |
| `PUT /students/:id` | auth | admin, tpc | none | No dept scope (VULN-04) |
| `DELETE /students/:id` | auth | admin, tpc | none | No dept scope (VULN-04) |

## `/api/spc` — [spcRoutes.js](../../server/src/routes/spcRoutes.js)

| Route | Auth | Roles | Scope | Issues |
|-------|------|-------|-------|--------|
| `GET /spc/verification-queue` | auth | spc | `assigned_spc_id = this SPC` AND `review_status='pending'` | OK (correctly scoped) |
| `PUT /spc/verify/:studentId` | auth | spc | `WHERE id=? AND assigned_spc_id=?` | OK |
| `PUT /spc/reject/:studentId` | auth | spc | `WHERE id=? AND assigned_spc_id=?`; reason required | OK |

## `/api/tpc` — [tpcRoutes.js](../../server/src/routes/tpcRoutes.js)

| Route | Auth | Roles | Scope | Issues |
|-------|------|-------|-------|--------|
| `GET /tpc` | auth | admin | all TPCs | OK |
| `POST /tpc` | auth | admin | — | OK |
| `GET /tpc/students` | auth | admin, tpc | `department = tpc.department` | OK (dept-scoped) |
| `GET /tpc/verification-queue` | auth | admin, tpc | dept + `review_status='spc_rejected'` | OK |
| `GET /tpc/spc-verified` | auth | admin, tpc | dept + spc_verified/pending-SPC | OK |
| `GET /tpc/branches` | auth | admin, tpc | dept | OK |
| `GET /tpc/spcs` | auth | admin, tpc | dept + branch | OK |
| `POST /tpc/assign-spc` | auth | admin, tpc | dept + branch; round-robin | OK; per-row UPDATE loop (perf, [04](04-QUERY-PERFORMANCE.md)) |
| `PUT /tpc/verify/:studentId` | auth | admin, tpc | `WHERE id=? AND department=?` | OK |
| `PUT /tpc/reject/:studentId` | auth | admin, tpc | dept; reason required | OK |
| `PUT /tpc/promote-spc/:studentId` | auth | admin, tpc | validates dept/phone; txn | Not dept-scoped on the target student (any TPC can promote any student) — Low |
| `PUT /tpc/demote-spc/:studentId` | auth | admin, tpc | txn | Not dept-scoped — Low |
| `PUT /tpc/:tpcId` | auth | admin, tpc | by `tpcId` | A TPC can edit **any** TPC row, not just their own — Medium |
| `DELETE /tpc/:tpcId` | auth | admin | — | OK |

## `/api/companies` — [companyRoutes.js](../../server/src/routes/companyRoutes.js)

| Route | Auth | Roles | Scope | Issues |
|-------|------|-------|-------|--------|
| `GET /companies` | auth | any | all; `SELECT *` | No pagination; any role reads all companies (likely intended) |
| `GET /companies/:id` | auth | any | by id; `SELECT *` | OK |
| `POST /companies` | auth | admin | — | OK |
| `PUT /companies/:id` | auth | admin | by id | OK |
| `DELETE /companies/:id` | auth | admin | by id | Cascades to drives (ON DELETE CASCADE) — confirm intent |

## `/api/drive` — [driveRoutes.js](../../server/src/routes/driveRoutes.js)

| Route | Auth | Roles | Scope | Issues |
|-------|------|-------|-------|--------|
| `POST /drive` | auth | admin | — | OK |
| `GET /drive` | auth | any | all drives + announcement id | No pagination (Low) |
| `GET /drive/my-drives` | auth | any | self (`students.user_id = req.user`) | OK (self-scoped) |
| `GET /drive/:driveId` | auth | any | by id | Any authed user reads any drive (likely intended for students) |
| `GET /drive/:driveId/eligible` | auth | admin | computed eligible list | OK |
| `PUT /drive/:driveId` | auth | admin | locked-drive guard | OK |
| `DELETE /drive/:driveId` | auth | admin | — | OK |
| `GET /drive/:driveId/students` | auth | **any** | none — returns others' PII | **PII leak (VULN-02, High)** |
| `POST /drive/:driveId/confirm-students` | auth | admin | SHORTLISTING-state guard; txn | OK |
| `POST /drive/:driveId/start-round-0` | auth | admin | state guard; txn | OK |
| `POST /drive/:driveId/finalize-prefilter` | auth | admin | stage guard; txn | OK; per-row loop (perf) |
| `POST /drive/:driveId/finalize-attendance` | auth | admin | stage guard; requires round date; txn | OK; per-row loop (perf) |
| `POST /drive/:driveId/advance-round` | auth | admin | RESULT-stage guard; txn | OK |
| `POST /drive/:driveId/complete` | auth | admin | RESULT-stage guard; txn | OK; per-row loop (perf) |
| `PATCH /drive/:driveId/students/:driveStudentId/attendance` | auth | admin | ATTENDANCE stage + active-student guard; txn | OK |
| `GET /drive/:driveId/rounds` | auth | any | round dates | Intended (students see schedule) |
| `PATCH /drive/:driveId/rounds/:roundNo/date` | auth | admin | round-exists guard; txn | OK |
| `GET /drive/:driveId/history` | auth | **any** | none — returns others' PII | **PII leak (VULN-02, High)** |
| `GET /drive/:driveId/my-results` | auth | any | self (`students.user_id = req.user`) | OK (self-scoped) |

## `/api/invite` — [invitationRoutes.js](../../server/src/routes/invitationRoutes.js)

| Route | Auth | Roles | Scope | Issues |
|-------|------|-------|-------|--------|
| `POST /invite/invite` | auth | admin | roles limited to tpc/admin | OK; no rate limit on outbound email (Low) |
| `GET /invite/verify/:token` | public | — | pending, unexpired invite | OK |
| `POST /invite/complete/:token` | public | — | valid invite → creates user | bcrypt cost 10 vs 12 (VULN-10) |
| `PATCH /invite/users/:userId/role` | auth | admin | txn; provisions/removes TPC row | OK |

## `/api/company-post` — [companyPostRoutes.js](../../server/src/routes/companyPostRoutes.js)

| Route | Auth | Roles | Scope | Issues |
|-------|------|-------|-------|--------|
| `POST /company-post` | auth | admin | txn; optional drive link | Validator runs **before** `requireAdmin` (ordering — leaks validation errors to non-admins; Low) |
| `GET /company-post` | auth | any | all + attachments | No pagination (Low) |
| `GET /company-post/:postId` | auth | any | by id | OK |
| `PUT /company-post/:postId` | auth | admin | `FOR UPDATE`; txn | Validator before `requireAdmin` (Low) |
| `DELETE /company-post/:postId` | auth | admin | attachments cascade | OK |

## `/api/notifications` — [notificationRoutes.js](../../server/src/routes/notificationRoutes.js)

| Route | Auth | Roles | Scope | Issues |
|-------|------|-------|-------|--------|
| `GET /notifications` | auth | any | self (`user_id = req.user`) | OK |
| `PATCH /notifications/read-all` | auth | any | self | OK |
| `PATCH /notifications/:notificationId/read` | auth | any | `WHERE id=? AND user_id=?` | OK |
| `DELETE /notifications/:notificationId` | auth | any | `WHERE id=? AND user_id=?` | OK |

---

## Totals & rollup

**67 registered endpoints** across 9 routers, each row mapping to exactly one `router.<verb>` registration verified by direct read of the routes files:

| Router | Endpoints |
|--------|-----------|
| authRoutes | 6 |
| studentRoutes | 7 |
| spcRoutes | 3 |
| tpcRoutes | 14 |
| companyRoutes | 5 |
| driveRoutes | 19 |
| invitationRoutes | 4 |
| companyPostRoutes | 5 |
| notificationRoutes | 4 |
| **Total** | **67** |

### Findings rollup by scoping dimension

| Dimension | State |
|-----------|-------|
| **Authentication** | Enforced on all non-auth/non-invite-completion routes. `auth` reloads role from DB each request (role changes take effect immediately). |
| **Role checks** | Present except **`POST /students`** (VULN-01). |
| **Ownership** | Correct for `students/me`, `notifications/*`, `drive/my-*`, `spc/*`. **Missing** for `drive/:id/students`, `drive/:id/history` (VULN-02). |
| **Department scoping** | Correct for the TPC verify/reject/assign/list pipeline. **Missing/inconsistent** for shared `students` reads, `PUT/DELETE /students/:id`, `PUT /tpc/:tpcId`, promote/demote (VULN-04, VULN-15). |
| **Branch scoping** | Used as a filter within department (SPC assignment, TPC lists) — not a security boundary, correct as-is. |
| **Least privilege** | Violated by VULN-01 (any→create student) and VULN-03 (SPC→all students). |

Remediation and sequencing: [08-REMEDIATION-PLAN.md](08-REMEDIATION-PLAN.md).
