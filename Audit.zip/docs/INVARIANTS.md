# Invariants

Properties that must **always** hold. Breaking one corrupts data or silently breaks a workflow. Each lists the invariant, why it matters, how it's enforced today, and the risk if violated. Treat these as the first things to check when a change touches the relevant area.

---

## Identity & roles

**INV-1. Exactly one profile row per user per type.** A `users` row has at most one `students`, one `tpc`, one `spc` row, keyed by a UNIQUE `user_id`. *Enforced:* UNIQUE constraints. *Risk if broken:* duplicate profiles → ambiguous scoping, double-counting in queues.

**INV-2. An SPC always has both a `students` row and an `spc` row, and `users.role='spc'`.** *Enforced:* `promoteSPC`/`demoteSPC` transactions keep the three in sync ([tpcController.js:170](../server/src/controllers/tpcController.js)). *Risk:* an `spc` row without a `students` row breaks `getTpcSpcs` (joins student roll_no/semester) and SPC assignment (needs the SPC's semester). **Never create an SPC except via promotion** (BR-6).

**INV-3. `users.role` is the authority; the JWT role claim is advisory.** `auth` re-reads role from the DB each request. *Risk:* trusting the token's role would let a demoted user keep privileges for up to 7 days.

---

## Department scoping (the string-match invariant)

**INV-4. `tpc.department`, `spc.department`, and `students.department` are stored in the identical canonical form ("Department of X").** *Why:* the entire verification pipeline scopes by exact string equality (`WHERE department = $tpcDept`). *Enforced:* the "Department of " prefix convention, applied by [migrations 021/022](../server/src/migrations/022_reconcile_schema.sql) and expected of every write path. *Risk if broken:* a mismatched string means a TPC's queue silently returns **zero** students — no error, just an empty screen. **This is the most fragile invariant in the system** (there is no reference table enforcing it — see [DATABASE.md](DATABASE.md) and audit [03-DATABASE-REVIEW.md](audit-2026-07/03-DATABASE-REVIEW.md)). Any new code that writes a department must use the canonical prefixed form.

**INV-5. SPC assignment respects (department, branch, semester) cohorts.** `assignStudentsToSpc` only assigns students to SPCs of the same department+branch+semester, excluding SPCs themselves. *Risk:* cross-cohort assignment would put students in front of an SPC who shouldn't review them.

---

## Verification

**INV-6. `review_status` only holds the five workflow values** (`pending`, `spc_verified`, `spc_rejected`, `verified`, `rejected`). *Enforced:* by controller code only — **no CHECK constraint today** (audit recommends adding one). *Risk:* a foreign value (as the `'approved'` bulk-import incident showed, [migration 035](../server/src/migrations/035_normalize_review_status.sql)) makes students invisible to every queue. Until the CHECK exists, any bulk write must use the exact vocabulary.

**INV-7. Only `verified` students are eligible for drives.** The eligibility query requires `review_status='verified'`. *Risk:* a scoping change that widened this would shortlist unverified students.

**INV-8. An SPC never reviews a student not assigned to them; a TPC never a student outside their department.** *Enforced:* `WHERE assigned_spc_id=?` (SPC) and `WHERE department=?` (TPC) on every verify/reject. *Risk:* removing the scope clause is a privilege escalation (audit VULN-03 is the read-side version of this).

---

## Drives & rounds

**INV-9. `drive_state` is the authoritative lifecycle; `drives.status` is decorative.** *Risk:* gating logic on `status` (upcoming/ongoing/…) instead of `drive_state` will make wrong decisions — the two are only loosely synced. Never branch on `status`.

**INV-10. A locked drive's eligibility criteria never change.** `is_locked` flips TRUE at Start Round 0 and is never reset; `updateDrive` refuses when locked. *Risk:* changing criteria after the shortlist was sent to the company desyncs the two sides.

**INV-11. Every `drive_students` status change is mirrored by an append to `drive_round_history`, in the same transaction.** *Enforced:* each workflow endpoint calls `recordHistory` inside its `BEGIN/COMMIT`. *Risk:* a status change without a history row loses the audit trail; the student's `my-results` view and the admin history diverge from reality. When adding a transition, you MUST append history.

**INV-12. A student appears at most once per drive.** UNIQUE `(drive_id, student_id)` on `drive_students`. *Enforced:* constraint + `DELETE`-then-INSERT in `confirmStudents`. *Risk:* duplicate rows double-process a student through rounds.

**INV-13. `drive_students.current_round` and `drives.current_round` stay consistent.** Shortlisted rows sit at -1; Start Round 0 moves all to 0; each advance moves SELECTED to `drive.current_round+1`. *Risk:* a per-student round out of sync with the drive breaks the round-scoped queries (`WHERE current_round = drive.current_round`).

**INV-14. A round cannot finalize attendance without a date set.** `finalizeAttendance` refuses if `drive_rounds.round_date` is NULL for the current round. *Risk:* placing students in a round with no scheduled date.

---

## Placement

**INV-15. A placed student is excluded from future eligibility.** `completeDrive` sets `placement_status='placed'`, and the eligibility query requires `unplaced` (unless the "allow placed in more drives" policy applies — verify current intent, commit `7b53cf6`). *Risk:* double-placing a student.

---

## Data derivation

**INV-16. CGPA is always server-derived from SPIs; never client-supplied.** `cgpa` is absent from the self-profile allowlist and recomputed on every write that touches SPIs/semester ([studentController.js:446](../server/src/controllers/studentController.js)). *Risk:* accepting a client `cgpa` lets students inflate eligibility.

**INV-17. `is_profile_complete` is a generated column — never written directly.** *Enforced:* `GENERATED ALWAYS AS ... STORED` ([migration 022](../server/src/migrations/022_reconcile_schema.sql)). *Risk:* code that tries to set it will error; code that reads a manually-maintained flag would drift.

**INV-18. Self-profile writes only touch allowlisted columns.** `upsertMyProfile` builds SQL identifiers from `MY_PROFILE_COLUMNS` only, never from `req.body` keys. *Risk:* removing the allowlist opens column-name injection and lets students write `review_status`/`assigned_spc_id`.

---

## Announcements

**INV-19. At most one announcement per drive.** UNIQUE `company_posts.drive_id` (NULLs unlimited). *Risk:* two announcements for one drive break the `getDrives` LEFT JOIN assumption (`post_id AS announcement_id` expects ≤1 match).

---

## When you change something
- Touching a **department** write path? Re-read INV-4.
- Adding a **drive transition**? Re-read INV-9, INV-11, INV-13.
- Touching **eligibility** or **profile**? Re-read INV-7, INV-16, INV-18.
- Adding a **bulk data import**? Re-read INV-4, INV-6 (use exact vocabularies).
