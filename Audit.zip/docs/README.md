# Documentation

Living reference for the placement-cell management portal. Written to let a new engineer — or an AI coding agent — understand the system in minutes instead of rediscovering it from the code.

> **Authoritative but not auto-generated.** These docs describe *why* the system behaves as it does (business rules, invariants, state machines), which the code alone doesn't tell you. When behavior and docs disagree, treat it as a bug in one of them and reconcile — don't silently follow the code. Update the relevant doc in the same PR that changes the behavior.

## Start here
1. [ARCHITECTURE.md](ARCHITECTURE.md) — the 2-tier system, tech stack, folder map.
2. [BUSINESS_RULES.md](BUSINESS_RULES.md) — the rules the whole product turns on.
3. [WORKFLOWS.md](WORKFLOWS.md) — end-to-end flows (onboarding, verification, drive lifecycle).
4. [STATE_MACHINES.md](STATE_MACHINES.md) — the drive/round and verification state machines.

## Living architecture spec
| Doc | Captures |
|-----|----------|
| [BUSINESS_RULES.md](BUSINESS_RULES.md) | Who can do what and why; eligibility, verification, placement rules. |
| [WORKFLOWS.md](WORKFLOWS.md) | Step-by-step user journeys across roles. |
| [STATE_MACHINES.md](STATE_MACHINES.md) | `drive_state` × `round_stage`, `drive_students.status`, `review_status` transitions. |
| [DATA_FLOW.md](DATA_FLOW.md) | How a request flows client → server → DB and back; notifications. |
| [INVARIANTS.md](INVARIANTS.md) | Properties that must always hold — break these and data corrupts. |

## Reference
| Doc | Covers |
|-----|--------|
| [DATABASE.md](DATABASE.md) | Tables, relationships, constraints, migrations. |
| [API.md](API.md) | Every endpoint, params, responses. |
| [AUTHENTICATION.md](AUTHENTICATION.md) | Signup, verify, login, tokens, reset. |
| [AUTHORIZATION.md](AUTHORIZATION.md) | Roles, scoping model, the SPC dual-identity. |
| [FRONTEND.md](FRONTEND.md) | React app structure, data layer, conventions. |
| [BACKEND.md](BACKEND.md) | Express structure, layering, shared libs. |
| [CONVENTIONS.md](CONVENTIONS.md) | Coding standards, naming, common pitfalls, extension points. |
| [ENVIRONMENT.md](ENVIRONMENT.md) | Env vars (names + purpose, never values). |
| [DEPLOYMENT.md](DEPLOYMENT.md) | Build, run, deploy, migrations. |
| [TESTING.md](TESTING.md) | Test strategy and how to add tests. |
| [TROUBLESHOOTING.md](TROUBLESHOOTING.md) | Common failures and fixes. |

## Audit
A production-readiness audit (2026-07-15) with the vulnerability report, authorization matrix, and a phased remediation plan is in [audit-2026-07/](audit-2026-07/). It **supersedes** the older top-level [`audit/`](../audit/) directory, which is a stale (2026-07-06) snapshot and is kept only for history.

## Not covered
- **File storage:** the app stores document links as pasted URLs (Google Drive), not uploads. The upload feature (multer + Google Drive API) is archived, unwired, in `server/src/deferred/`. See [BUSINESS_RULES.md](BUSINESS_RULES.md) §Documents. There is intentionally no `FILE_STORAGE.md` for a live upload pipeline because none is mounted.
