# Conventions

Coding standards, naming, and the pitfalls most likely to bite. Read this before your first change.

## General
- **Match the surrounding code.** Comment density, naming, and idiom should look like the file you're editing.
- Comments explain **why**, not what. The codebase already does this well (see the migration and controller headers) — keep it up.
- No new page-specific CSS files; Tailwind utilities + shadcn (frontend rule, [CLAUDE.md](../CLAUDE.md)).

## Backend
- **ESM** (`import`/`export`), Node + Express 5. Files are `camelCase.js` grouped by layer.
- **Always parameterize SQL** (`$1,$2…`). If you need dynamic columns, use a **hardcoded allowlist** for identifiers (never `req.body` keys) — see `MY_PROFILE_COLUMNS`.
- **Role check before body validation** in the route chain.
- **Multi-step writes go in a transaction** (`pool.connect` + BEGIN/COMMIT/ROLLBACK + `release()` in `finally`). If the write changes drive or verification state, append `drive_round_history` and any notifications **in the same transaction** (INV-11, BR-25).
- **Never accept `cgpa`** from clients; derive it via `lib/cgpa.js`. Never write `is_profile_complete` (generated column).
- **Department strings must be canonical** ("Department of X"); never store a bare department (INV-4).
- Map errors through `lib/dbError.js`; return generic messages (don't leak `error.message`).
- Don't add controller→controller imports; put shared logic in `lib/` or a service.

## Frontend
- **TypeScript strict.** Type service responses with exported interfaces (mirror the DB shape).
- **All network I/O through `axiosInstance`** and the `services/` layer — never call `fetch`/`axios` directly in components.
- **Query keys only from `queryKeys.ts`.** Add new ones there.
- **Mutations invalidate, not refetch.** Invalidate the specific affected keys; prefer the shared invalidator pattern.
- Prefer an existing shadcn/`components/dashboard` component before writing new markup; extract shared UI rather than duplicating (project rule).
- Use `components/dashboard/states.tsx` for loading/error/empty.
- Typecheck with `tsc --noEmit -p tsconfig.app.json`.

## Database / migrations
- One change per migration file, numbered sequentially. **Make it idempotent** (`ADD COLUMN IF NOT EXISTS`, `information_schema` guards) — the later migrations model this well; follow them, not the early plain `CREATE`s.
- Add a `-- Purpose:` header explaining *why*.
- New status/enum-like columns should get a **CHECK constraint** (the missing ones on `review_status`/`placement_status`/`role` caused real bugs).
- Migrations are applied **by hand** today — coordinate applying yours to the live DB, and update [schema.md](../schema.md).

## Naming
- DB: snake_case tables/columns; `*_id` FKs; PKs are `id` (uuid/bigserial) or `<entity>_id` (serial) — inconsistent across tables, match the table you're touching.
- Routes: resource-oriented; id params vary (`:id`, `:driveId`, `:studentId`) — match the router.
- React: `PascalCase` components/pages, `useX` hooks, `xService` services.

## Common pitfalls (learned the hard way)
1. **Generic 500 on verify/reject/assign** → usually a **missing column** because the live DB lagged the migration files. Check migration 022 / apply pending migrations ([TROUBLESHOOTING.md](TROUBLESHOOTING.md), [memory: db-migrations-applied-manually]).
2. **Empty TPC queue** → a **department string mismatch** (INV-4), not a code bug.
3. **Gating logic on `drives.status`** instead of `drive_state` — `status` is decorative (INV-9).
4. **Fresh DB won't build from migrations** — 003 references `drives` before 010 creates it, and 004 indexes non-existent columns. Apply out of order or fix per the audit.
5. **Forgetting the history append** on a new drive transition — breaks the audit trail and `my-results`.
6. **Writing a client `cgpa`** — silently ignored (allowlist) but a sign of misunderstanding; it's server-derived.
7. **Plain `tsc --noEmit`** in `client/` does nothing — use the `-p tsconfig.app.json` form.

## Extension points
- **New drive stage / review status:** [STATE_MACHINES.md](STATE_MACHINES.md) "Extension points".
- **New endpoint:** [BACKEND.md](BACKEND.md) recipe.
- **New notification event:** call `notifyStudentsByIds`/`createNotificationForRole` inside the triggering transaction.
- **New role:** touch `users.role` CHECK (add one), role middleware, `ProtectedRoute` groups, and this doc + [AUTHORIZATION.md](AUTHORIZATION.md).
