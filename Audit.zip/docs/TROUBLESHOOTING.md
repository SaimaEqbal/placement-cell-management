# Troubleshooting

Common failures and their real causes. Many "mysterious 500s" here trace to the **manually-applied migrations** — the live DB can lag the SQL files.

---

### Generic 500 on TPC/SPC verify, reject, or SPC assignment
**Cause:** a **missing column** on the live DB — `students.rejection_reason` / `assigned_spc_id` / `semester` (from migration 018) were historically never applied. The controller SQL references them and Postgres errors.
**Fix:** apply the pending migrations, especially [022_reconcile_schema.sql](../server/src/migrations/022_reconcile_schema.sql) — it's the idempotent reconcile that backfills every drifted column. See [memory: db-migrations-applied-manually].

### A TPC's queue / roster is empty (but students exist)
**Cause:** **department string mismatch** (INV-4). Scoping is `WHERE department = tpc.department` by exact string; if the student rows aren't in the canonical "Department of X" form, the match returns nothing — silently, no error.
**Fix:** verify `students.department`, `tpc.department`, `spc.department` all use the prefixed canonical form (migrations 021/022 apply it). Fix the offending rows.

### Students not appearing in verification queues at all
**Cause:** `review_status` holds a value outside the workflow vocabulary — e.g. a bulk import wrote `'approved'`, which no queue reads ([migration 035](../server/src/migrations/035_normalize_review_status.sql) repaired this). There's no CHECK constraint to prevent it (INV-6).
**Fix:** normalize `review_status` to `pending`/`spc_verified`/`spc_rejected`/`verified`/`rejected`. Add the CHECK constraint (audit P2-4).

### Fresh database won't build from the migrations
**Cause:** the migration set isn't replayable — [003](../server/src/migrations/003_create_applications.sql) references `drives` before [010](../server/src/migrations/010_create_drives.sql) creates it, and [004](../server/src/migrations/004_create_indexes.sql) indexes non-existent columns (`companies.drive_date`, `applications.company_id`).
**Fix (interim):** apply tables in dependency order or restore a known-good dump. **Fix (proper):** audit P2-1/P2-2 — adopt a runner + generate a `schema.sql` baseline.

### Login succeeds but every API call 401s
**Cause:** the token isn't reaching the server, or `JWT_ACCESS_SECRET` differs between the signer and verifier.
**Check:** the client attaches `Authorization: Bearer` (axios interceptor) — confirm the token is in `localStorage["upms.auth.token"]`. Confirm the server's `JWT_ACCESS_SECRET` matches the one that signed the token (a secret rotation invalidates all existing tokens — everyone must re-login).

### User can't log in even with the right password
**Causes:** (a) `is_verified` is false → 403 "Verify your email first"; (b) the account was seeded with a non-bcrypt `password_hash` (the `1234` admin seed, VULN-05) → `bcrypt.compare` always fails.
**Fix:** verify the email, or reset the password to a proper bcrypt hash. Remove the hardcoded seed.

### CORS errors in the browser
**Cause:** currently `cors()` is wide open, so CORS errors usually mean the API is unreachable (wrong `VITE_API_BASE_URL`) rather than a policy block. Once the allow-list lands (VULN-11), a mismatch between `FRONTEND_URL` and the actual origin will block requests.
**Fix:** confirm `VITE_API_BASE_URL` points at the running API; once locked down, ensure `FRONTEND_URL` lists the real frontend origin.

### Email (verification / reset / invite) not arriving
**Cause:** Brevo not configured or failing. `emailService` logs whether `BREVO_API_KEY` exists at import.
**Notes:** invite creation is best-effort on email — the invite link is returned in the response even if the email fails, so an admin can copy it. Signup/verification email failure *does* fail the request.

### `tsc --noEmit` reports nothing in `client/`
**Cause:** plain `tsc --noEmit` is a no-op in `client/`. **Fix:** use `tsc --noEmit -p tsconfig.app.json` (see [memory: client-typecheck-command]).

### Drive transition returns 409
**Cause:** the drive isn't in the required state — e.g. confirming students after Round 0 started (locked), finalizing attendance without a round date, advancing with zero selected. This is the state machine working ([STATE_MACHINES.md](STATE_MACHINES.md)).
**Fix:** check `drive_state` + `round_stage`; take the transition valid from the current state.

### Can't delete a user (FK error)
**Cause:** `company_posts.posted_by` is `NOT NULL ... ON DELETE SET NULL` — a self-contradicting FK that errors when the user has posts (audit).
**Fix:** apply the FK correction (drop NOT NULL or change the cascade) — audit P2-3.

---

## When in doubt
1. Check whether the live DB has the columns/constraints the code expects — run/inspect [022_reconcile_schema.sql](../server/src/migrations/022_reconcile_schema.sql).
2. Check the department strings (INV-4) and the status vocabularies (INV-6).
3. Read the relevant invariant in [INVARIANTS.md](INVARIANTS.md) before "fixing" something that looks wrong — it may be load-bearing.
