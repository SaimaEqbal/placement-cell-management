# API Reference

Base URL: `VITE_API_BASE_URL` (default `http://localhost:3000/api`). All requests except the public auth/invite routes require `Authorization: Bearer <jwt>`. Bodies are JSON, validated with Zod.

Auth/role columns match the [authorization matrix](audit-2026-07/02-AUTHORIZATION-MATRIX.md); this doc is the endpoint reference. **⚠️ = known issue, see the matrix.**

## Conventions
- **Auth:** `public` or `JWT`.
- **Roles:** which roles may call it (or *any authenticated*).
- Response shapes are currently inconsistent (bare resource / bare array / `{message}` / `{message, resource}` / wrapped) — see [06-API-DESIGN.md](audit-2026-07/06-API-DESIGN.md). Documented per-endpoint below.

---

## Auth — `/auth`
| Method | Path | Auth | Body | Returns |
|--------|------|------|------|---------|
| POST | `/auth/signup` | public | `{email, password}` | `{message, user}` |
| GET | `/auth/verify-email?token=` | public | — | `{message}` |
| POST | `/auth/login` | public | `{email, password}` | `{token}` (7-day JWT) |
| POST | `/auth/resend-verification` | public | `{email}` | `{message}` |
| POST | `/auth/forgot-password` | public | `{email}` | `{message}` (non-enumerating) |
| POST | `/auth/reset-password` | public | `{token, password}` | `{message}` |

## Students — `/students`
| Method | Path | Auth | Roles | Notes |
|--------|------|------|-------|-------|
| GET | `/students/me` | JWT | any | own profile |
| PUT | `/students/me` | JWT | any | partial upsert (wizard); CGPA derived; allowlisted cols |
| GET | `/students` | JWT | admin, tpc, spc ⚠️ | full table (SELECT *, no pagination); **SPC over-reach** |
| POST | `/students` | JWT | **any ⚠️** | **no role guard (VULN-01)** |
| GET | `/students/:id` | JWT | admin, tpc, spc ⚠️ | no dept scope |
| PUT | `/students/:id` | JWT | admin, tpc | staff edit; no dept scope ⚠️ |
| DELETE | `/students/:id` | JWT | admin, tpc | no dept scope ⚠️ |

## SPC — `/spc`
| Method | Path | Auth | Roles | Notes |
|--------|------|------|-------|-------|
| GET | `/spc/verification-queue` | JWT | spc | assigned + pending |
| PUT | `/spc/verify/:studentId` | JWT | spc | scoped `assigned_spc_id` → spc_verified |
| PUT | `/spc/reject/:studentId` | JWT | spc | `{reason}` → spc_rejected |

## TPC — `/tpc`
| Method | Path | Auth | Roles | Notes |
|--------|------|------|-------|-------|
| GET | `/tpc` | JWT | admin | all TPCs |
| POST | `/tpc` | JWT | admin | `{user_id, name, email, phone, department, branch}` |
| GET | `/tpc/students?rollNo=&year=` | JWT | admin, tpc | dept-scoped roster |
| GET | `/tpc/verification-queue?branch=&year=` | JWT | admin, tpc | spc_rejected |
| GET | `/tpc/spc-verified?branch=&year=` | JWT | admin, tpc | spc_verified + pending SPCs |
| GET | `/tpc/branches` | JWT | admin, tpc | distinct branches in dept |
| GET | `/tpc/spcs?branch=&year=` | JWT | admin, tpc | SPCs in dept+branch |
| POST | `/tpc/assign-spc` | JWT | admin, tpc | `{branch}` — round-robin assignment |
| PUT | `/tpc/verify/:studentId` | JWT | admin, tpc | dept-scoped → verified |
| PUT | `/tpc/reject/:studentId` | JWT | admin, tpc | `{reason}` → rejected |
| PUT | `/tpc/promote-spc/:studentId` | JWT | admin, tpc | promote student to SPC |
| PUT | `/tpc/demote-spc/:studentId` | JWT | admin, tpc | demote SPC to student |
| PUT | `/tpc/:tpcId` | JWT | admin, tpc | ⚠️ any TPC can edit any TPC |
| DELETE | `/tpc/:tpcId` | JWT | admin | — |

## Companies — `/companies`
| Method | Path | Auth | Roles |
|--------|------|------|-------|
| GET | `/companies` | JWT | any (no pagination) |
| GET | `/companies/:id` | JWT | any |
| POST | `/companies` | JWT | admin |
| PUT | `/companies/:id` | JWT | admin |
| DELETE | `/companies/:id` | JWT | admin (cascades to drives) |

## Drives — `/drive`
| Method | Path | Auth | Roles | Notes |
|--------|------|------|-------|-------|
| POST | `/drive` | JWT | admin | create (+ optional announcement); returns `{drive, eligibleStudents, announcement}` |
| GET | `/drive` | JWT | any | list + `announcement_id` |
| GET | `/drive/my-drives` | JWT | any | self-scoped |
| GET | `/drive/:driveId` | JWT | any | detail |
| GET | `/drive/:driveId/eligible` | JWT | admin | recompute eligible list |
| PUT | `/drive/:driveId` | JWT | admin | locked-drive guard; clears shortlist |
| DELETE | `/drive/:driveId` | JWT | admin | — |
| GET | `/drive/:driveId/students` | JWT | **any ⚠️** | shortlist w/ PII — **VULN-02** |
| POST | `/drive/:driveId/confirm-students` | JWT | admin | `{studentIds}` |
| POST | `/drive/:driveId/start-round-0` | JWT | admin | lock + round 0 |
| POST | `/drive/:driveId/finalize-prefilter` | JWT | admin | `{removed:[{driveStudentId,reason}]}` |
| POST | `/drive/:driveId/finalize-attendance` | JWT | admin | requires round date |
| POST | `/drive/:driveId/advance-round` | JWT | admin | `{rejected:[...]}` |
| POST | `/drive/:driveId/complete` | JWT | admin | `{rejected:[...]}` → place selected |
| PATCH | `/drive/:driveId/students/:driveStudentId/attendance` | JWT | admin | `{present}` |
| GET | `/drive/:driveId/rounds` | JWT | any | round dates |
| PATCH | `/drive/:driveId/rounds/:roundNo/date` | JWT | admin | `{round_date}` |
| GET | `/drive/:driveId/history?round=` | JWT | **any ⚠️** | round history w/ PII — **VULN-02** |
| GET | `/drive/:driveId/my-results` | JWT | any | self-scoped |

## Invitations — `/invite`
| Method | Path | Auth | Roles | Notes |
|--------|------|------|-------|-------|
| POST | `/invite/invite` | JWT | admin | `{email, role}` (tpc/admin only) |
| GET | `/invite/verify/:token` | public | — | returns `{email, role}` |
| POST | `/invite/complete/:token` | public | — | `{name, phone, department, branch, password}` |
| PATCH | `/invite/users/:userId/role` | JWT | admin | `{role}` |

## Company posts (announcements) — `/company-post`
| Method | Path | Auth | Roles | Notes |
|--------|------|------|-------|-------|
| POST | `/company-post` | JWT | admin | `{title, content, attachments[], drive_id?}` |
| GET | `/company-post` | JWT | any | all + attachments |
| GET | `/company-post/:postId` | JWT | any | one + attachments |
| PUT | `/company-post/:postId` | JWT | admin | title/content/attachments |
| DELETE | `/company-post/:postId` | JWT | admin | attachments cascade |

## Notifications — `/notifications`
| Method | Path | Auth | Roles | Notes |
|--------|------|------|-------|-------|
| GET | `/notifications` | JWT | any | self |
| PATCH | `/notifications/read-all` | JWT | any | self |
| PATCH | `/notifications/:notificationId/read` | JWT | any | self |
| DELETE | `/notifications/:notificationId` | JWT | any | self |

---

## Error responses
Generic `{message}` (and `{errors:[...]}` / `fieldErrors` for Zod validation). Status codes: 400 validation, 401 unauthenticated, 403 role/unverified, 404 not found, 409 conflict/state-machine violation, 500 server. Stack traces are never returned (except `signup` leaks `error.message` — VULN-07). No pagination envelope yet (audit [06](audit-2026-07/06-API-DESIGN.md)).
