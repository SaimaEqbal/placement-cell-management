# Business Rules

The rules the product turns on. Each states the rule, **why** it exists, and where it is enforced. These are the facts most likely to be misunderstood by someone reading only the code.

---

## Roles & identity

**BR-1. Four roles: `student`, `spc`, `tpc`, `admin`.** A user's role lives in `users.role` and is the single source of truth. The JWT carries a `role` claim for convenience, but `auth` middleware re-reads the role from the DB on every request, so role changes take effect immediately.

**BR-2. An SPC is a student with extra duties.** A Student Placement Coordinator is a promoted student. They keep their `students` row *and* gain an `spc` row and `users.role = 'spc'`. They still complete a profile and get verified like any student, **but** an SPC is verified directly by the TPC (they skip SPC review — you can't review yourself). *Why:* SPCs distribute the verification workload within a department without needing separate staff accounts.

**BR-3. A TPC oversees exactly one department.** `tpc.department` scopes everything a TPC does — their student roster, verification queues, and SPC assignment are all filtered to that department. *Why:* departments are administratively independent; a TPC must not act on another department's students.

**BR-4. Admin is unscoped.** Admins manage companies, drives, invitations, announcements, and all students across all departments.

---

## Onboarding & invitations

**BR-5. Students self-register; staff are invited.** Students sign up with an institutional email, verify it, and build a profile. TPCs and Admins are created by an **admin invitation** (email + role → tokenized link → complete registration). *Why:* students are many and self-serve; staff are few, privileged, and must be vetted.

**BR-6. Only TPC and Admin can be invited by email.** SPCs are **never** invited — they are created by promoting an existing student ([invitationController.js:14](../server/src/controllers/invitationController.js)). Inviting an "spc" would create a user with no `students`/`spc` linkage — a broken account. *Why:* SPC identity is derived from an existing student record (BR-2).

**BR-7. Institutional email required for students.** Enforced client-side in `lib/validation.ts` and server-side in the Zod schemas. *Why:* ties an account to a real enrolled student.

---

## Profile & academics

**BR-8. CGPA is derived, never submitted.** The server computes CGPA from per-semester SPIs as a weighted average over *completed* semesters (a student in semester N has completed 1..N-1). Weights: sem 1–2 = 0.25, 3–4 = 0.50, 5–6 = 0.75, 7–8 = 1.00 ([lib/cgpa.js](../server/src/lib/cgpa.js)). The client mirrors the same formula for preview only; the stored value is authoritative. *Why:* prevents students inflating their own CGPA; keeps it consistent with the SPIs.

**BR-9. `semester` is 5–8 only.** CHECK constraint `students_semester_check`. *Why:* placement is for pre-final/final-year students.

**BR-10. Profile completeness is computed, not claimed.** `students.is_profile_complete` is a generated STORED column: true only when phone, branch, graduation_year, cgpa, gender, region, religion, DOB, all four document URLs, semester, and the SPIs for every completed semester are present ([migration 022](../server/src/migrations/022_reconcile_schema.sql)). *Why:* eligibility and SPC assignment require a complete profile; a computed column can't drift from the data.

**BR-11. Documents are pasted URLs, not uploads.** `resume_url` and the three marksheet URLs are hosted links (Google Drive). The upload pipeline was built then rolled back ([migration 031], archived in `server/src/deferred/`). *Why:* an intentional product simplification — see [memory: student-document-uploads]. **Caveat:** these are validated as plain strings, not URLs (audit VULN-14).

**BR-12. Department strings are canonical with a "Department of " prefix.** Every `department` value (students, tpc, spc) is stored prefixed ([migrations 021/022](../server/src/migrations/022_reconcile_schema.sql)). *Why:* the verification pipeline matches `tpc.department = students.department` by exact string equality; a canonical form keeps the match reliable. **This is a load-bearing invariant** — see [INVARIANTS.md](INVARIANTS.md).

---

## Verification

**BR-13. Verification is a two-tier, department-scoped pipeline.** A student's `review_status` moves `pending → (SPC) → spc_verified | spc_rejected → (TPC) → verified | rejected`. An SPC handles their **assigned** students; the TPC gives final approval and handles SPC-rejected students. *Why:* distributes review load (SPC) while keeping final authority with staff (TPC). Full transitions in [STATE_MACHINES.md](STATE_MACHINES.md).

**BR-14. An SPC only acts on students assigned to them.** Every SPC verify/reject is `WHERE id=? AND assigned_spc_id=?` ([spcController.js](../server/src/controllers/spcController.js)). Assignment is done by the TPC, round-robin within a (branch, semester) cohort, excluding SPCs themselves ([tpcController.js:483](../server/src/controllers/tpcController.js)). *Why:* clear ownership; no two SPCs review the same student.

**BR-15. Editing an academic/course field resets verification to pending.** Changing anything except the "personal info" allowlist (name, roll_no, email, phone, gender, region, religion, DOB, resume_url) flips `review_status` back to `pending` ([studentController.js:238](../server/src/controllers/studentController.js)). *Why:* re-verify when the data that was verified changes; cosmetic edits don't churn the queue.

---

## Companies, drives, eligibility

**BR-16. Companies are records, not portals.** Companies exist as data owned by admins; there is no company-facing login. *Why:* recruiters interact offline; the portal manages the process internally.

**BR-17. Students do not apply to drives — admins shortlist them.** The old application model is gone (legacy `applications` table, `drives.drive_date`/`application_deadline` dropped in migration 029). Instead the admin sees an **auto-generated eligible list** and confirms a subset into `drive_students`. *Why:* placement cells drive the process; eligibility is objective and computed.

**BR-18. Eligibility is computed on the fly, never stored.** A student is eligible for a drive when they are `verified`, `unplaced`, meet `minimum_cgpa`, are within both backlog caps, belong to an `allowed_branches` entry, are in an `allowed_batches` graduation year (if set), and — if `minimum_cgpa_throughout` is set — every recorded semester SPI meets that floor ([driveController.js:11](../server/src/controllers/driveController.js)). *Why:* eligibility must always reflect current student data; storing it would let it go stale.

**BR-19. A placed student is excluded from future drives.** Completing a drive sets `placement_status = 'placed'` for selected students ([driveController.js:1073](../server/src/controllers/driveController.js)), which removes them from every future eligible list. *Why:* one placement per student is the default policy. (Commit `7b53cf6` "Allow placed students in more drives" suggests this may be relaxing — verify current intent before relying on it.)

**BR-20. A drive locks once Round 0 starts.** Eligibility criteria are immutable after `Start Round 0` (`is_locked = TRUE`, never reset). Editing a drive before that clears the tentative shortlist ([driveController.js:411](../server/src/controllers/driveController.js)). *Why:* the shortlist has been sent to the company; changing criteria afterward would desync the two sides.

**BR-21. Rounds are open-ended.** The number of rounds is not fixed up front; the admin runs another round (`advance-round`) or ends the drive (`complete`) at each results stage. Round 0 is resume screening; rounds ≥ 1 have prefilter → attendance → result sub-stages. *Why:* real recruitment has a variable number of rounds decided as it unfolds. Full machine in [STATE_MACHINES.md](STATE_MACHINES.md).

---

## Announcements

**BR-22. "Announcements" are `company_posts`.** The announcements feature is stored in the `company_posts` table (the only remaining `post_type` is `'announcement'`; `'email'` was removed in migration 032). *Why:* historical naming — see [memory: announcements-are-company-posts].

**BR-23. An announcement may link to at most one drive; a drive to at most one announcement.** `company_posts.drive_id` is UNIQUE and nullable ([migration 033](../server/src/migrations/033.sql)). Standalone announcements (NULL drive_id) are unlimited. A drive can be created with its announcement atomically in one request. Deleting a drive cascades to its announcement; deleting the announcement never touches the drive. *Why:* a drive's announcement is a child of the drive.

**BR-24. Attachments are pasted Drive links with display order.** `company_post_attachments` holds `file_name` + `file_url` (a URL) + `display_order`, saved transactionally with the post ([migration 032](../server/src/migrations/032.sql)). No file upload.

---

## Notifications

**BR-25. Notifications are shared and self-scoped.** One `notifications` table for all roles; every user only reads/writes their own (`user_id = req.user`). Domain events (shortlisted, round cleared, placed, removed, absent, round scheduled) raise notifications inside the same transaction as the action ([driveController.js:112](../server/src/controllers/driveController.js)). *Why:* atomicity — a student is notified iff the action that concerns them committed.
