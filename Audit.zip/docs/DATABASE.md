# Database

PostgreSQL, accessed with `pg` (parameterized raw SQL). Column-level reference: [schema.md](../schema.md). This doc adds relationships, the *why*, and the gotchas. For migration defects and index recommendations see the audit ([03-DATABASE-REVIEW.md](audit-2026-07/03-DATABASE-REVIEW.md)).

## Tables (14)

| Table | Purpose | Key relationships |
|-------|---------|-------------------|
| `users` | Auth identity + role | `id uuid PK`; 1:1 to students/tpc/spc via their `user_id` |
| `students` | Student profile, marks, verification state | `user_id UNIQUE→users`; `assigned_spc_id→spc` (SET NULL) |
| `tpc` | Department staff | `user_id UNIQUE→users`; `department` scopes their work |
| `spc` | Promoted student coordinator | `user_id UNIQUE→users` |
| `companies` | Recruiter records | `created_by→users` |
| `drives` | A recruitment drive + lifecycle state | `company_id→companies` (CASCADE) |
| `drive_students` | Confirmed shortlist + current per-student state | `drive_id→drives` (CASCADE), `student_id→students` (CASCADE), UNIQUE(drive_id,student_id) |
| `drive_rounds` | Per-round date (NULL=TBD) | PK(drive_id,round_no), `drive_id→drives` (CASCADE) |
| `drive_round_history` | Append-only audit of every round event | `drive_id`,`student_id` (CASCADE); indexed (drive,round),(drive,student) |
| `company_posts` | Announcements | `posted_by→users`, `drive_id→drives` UNIQUE (CASCADE) |
| `company_post_attachments` | Pasted-link attachments | `post_id→company_posts` (CASCADE), `display_order` |
| `notifications` | Per-user notifications (all roles) | `user_id→users` |
| `invitations` | Pending TPC/Admin invites | `email UNIQUE`, `token UNIQUE`, `expires_at` |
| `applications` | **LEGACY / unused** | superseded by `drive_students`; recommend dropping |

## Entity relationships

```
users ─1:1─ students ─(assigned_spc_id)─► spc
      ─1:1─ tpc
      ─1:1─ spc
companies ─1:N─ drives ─1:N─ drive_students ──► students
                       ─1:N─ drive_rounds
                       ─1:N─ drive_round_history ──► students
                       ─1:1─ company_posts ─1:N─ company_post_attachments
users ─1:N─ notifications
```

## The three state columns
- `students.review_status` — verification state machine (pending → spc_verified/spc_rejected → verified/rejected).
- `drives.drive_state` + `round_stage` + `current_round` + `is_locked` — drive lifecycle.
- `drive_students.status` + `attendance_mark` — per-student state within a drive.

All three are documented in [STATE_MACHINES.md](STATE_MACHINES.md).

## Constraints worth knowing
- `students.semester CHECK BETWEEN 5 AND 8`.
- `students.is_profile_complete` — **generated STORED** column (never write it directly, INV-17).
- `drives.drive_state` / `round_stage` CHECKs; `drive_students.status` / `attendance_mark` CHECKs; `drive_round_history.stage` / `result` CHECKs.
- `company_posts.post_type CHECK IN ('announcement')` (email type removed).
- UNIQUE: `students.roll_no`, `students.email`, `students.user_id`, `company_posts.drive_id`, `drive_students(drive_id,student_id)`, `invitations.email`, `invitations.token`.
- **Missing (recommended):** CHECKs on `review_status`, `placement_status`, `users.role` (audit §4).

## Gotchas
- **Department string-match (INV-4):** `department` is a denormalized string; the "Department of " prefix must be canonical everywhere or TPC queues silently return nothing. No reference table enforces it.
- **`company_posts.posted_by` FK bug:** declared `NOT NULL ... ON DELETE SET NULL` — contradictory; blocks deleting a posting user (audit).
- **Migration 004 is broken** (indexes on non-existent columns) and **migration 003 references `drives` before it exists** — the set is not replayable from scratch; the live DB was applied by hand. Migration 022 is a reconcile script for the resulting drift.
- **Migrations are applied manually — no runner.** The live DB can lag the SQL files; a generic 500 on verify/reject/assign historically meant a missing column (see [memory: db-migrations-applied-manually]). Migration 022 backfills those.
- **Duplicate migration number 015** (two files); 027–034 renamed to bare numbers (content preserved).

## Migrations
`server/src/migrations/001…037`, applied by hand. The later ones (022, 024, 025, 026, 032, 035) are idempotent and well-commented; the early ones are plain `CREATE`. **Recommendation (audit):** adopt a migration runner + a generated `schema.sql` baseline; fix 003/004; add down-migrations. See [audit-2026-07/03-DATABASE-REVIEW.md](audit-2026-07/03-DATABASE-REVIEW.md) §6.
