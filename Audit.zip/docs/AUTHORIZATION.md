# Authorization

Two layers: **role** (middleware) and **scope** (in-controller ownership/department filters). The route-by-route table is the audit's [authorization matrix](audit-2026-07/02-AUTHORIZATION-MATRIX.md); this doc explains the model and its intended semantics.

## Roles
| Role | Who | Powers |
|------|-----|--------|
| `student` | self-registered | own profile; own drive views; own notifications |
| `spc` | a **promoted student** | everything a student has, **plus** verify/reject the students **assigned to them** |
| `tpc` | invited department staff | manage + verify students **in their department**; assign SPCs; manage TPC roster |
| `admin` | invited | everything, unscoped: companies, drives, invitations, announcements, all students |

## SPC dual identity
An SPC is a student with an extra `spc` row and `users.role='spc'` (BR-2, INV-2). Consequences:
- SPC routes (`allowedRoles` including `spc`) also grant the student routes — the client intentionally lets `spc` into student pages.
- An SPC is verified **directly by the TPC** (skips SPC review — can't self-review). The TPC "awaiting verification" queue surfaces SPCs whose own record is still `pending`.
- SPCs are created only by promotion, never by invite (BR-6).

## Role middleware
[roleMiddleware.js](../server/src/middleware/roleMiddleware.js): `requireSPC`, `requireTPC`, `requireAdmin`, `requireAdminTPC`, `requireAdminTPCSPC`. Pure role checks — **no ownership or department logic**. Scoping is enforced *inside controllers*.

## Scoping model (intended)
| Actor | Student reads | Verify/act |
|-------|---------------|-----------|
| **SPC** | **only students assigned to them** (`assigned_spc_id`) | only assigned students |
| **TPC** | **any student** (TPC-wide read is accepted by design) | only students **in their department** |
| **Admin** | all students | all |

This is the confirmed product model. Enforcement today:
- ✅ SPC verify/reject/queue are assignment-scoped ([spcController.js](../server/src/controllers/spcController.js)).
- ✅ TPC verify/reject/assign/lists are department-scoped ([tpcController.js](../server/src/controllers/tpcController.js)).
- ⚠️ **But** the shared `GET /students` and `GET /students/:id` (gated `requireAdminTPCSPC`) let an **SPC read every student**, violating the model (audit **VULN-03**). And `GET /drive/:id/students` / `/history` leak PII to any authenticated user (**VULN-02**). These are the top authorization fixes.

## Department scoping mechanics
Scoping is by **exact string equality** on the denormalized `department` column (`WHERE department = tpc.department`), relying on the canonical "Department of X" form (INV-4). There is no `departments` reference table — a mismatch silently yields an empty result, not an error. Any code that writes a department must use the canonical prefixed form.

## Branch scoping
`branch` is used as a **filter within a department** (SPC assignment cohorts, TPC list filters), not as a security boundary. Correct as-is.

## Client-side guards
`ProtectedRoute` ([routes/ProtectedRoute.tsx](../client/src/routes/ProtectedRoute.tsx)) gates route groups by `allowedRoles`, with the role decoded from the JWT. **These are UX only** — the server must independently enforce every rule, because the client decode is unverified. Where a server route is under-protected (VULN-01/02/03), the client guard provides no real protection.

## Least privilege — current violations
- `POST /students`: any authenticated user (VULN-01).
- `GET /students*`: SPC reads all students (VULN-03).
- `GET /drive/:id/students|history`: any user reads others' PII (VULN-02).
- `PUT /tpc/:tpcId`: any TPC edits any TPC row.

Remediation: [audit-2026-07/08-REMEDIATION-PLAN.md](audit-2026-07/08-REMEDIATION-PLAN.md) Phase 0.
