# State Machines

The three state machines that govern the app. Getting these wrong corrupts data, so they are documented explicitly. Enforcement is server-side, under row locks, inside transactions.

---

## 1. Drive lifecycle — `drives.drive_state` × `drives.round_stage` × `drives.current_round`

Authoritative columns ([migration 024](../server/src/migrations/024_drive_workflow_columns.sql)):
- `drive_state`: `SHORTLISTING` → `ROUND_IN_PROGRESS` → `COMPLETED`
- `current_round`: `-1` shortlisting · `0` resume screening · `1..N` interview rounds
- `round_stage` (only meaningful when `ROUND_IN_PROGRESS`, round ≥ 1): `PREFILTER` → `ATTENDANCE` → `RESULT`. NULL while `SHORTLISTING`; round 0 sits directly at `RESULT`.
- `is_locked`: FALSE while `SHORTLISTING`, flips TRUE at Start Round 0, never returns.

> The legacy `drives.status` (`upcoming`/`ongoing`/`completed`/`cancelled`) is kept only loosely in sync and **must never gate logic** — `drive_state` is authoritative ([migration 024](../server/src/migrations/024_drive_workflow_columns.sql)).

```
                        ┌──────────────┐
   createDrive ───────► │ SHORTLISTING │  current_round = -1, round_stage = NULL, is_locked = false
                        └──────┬───────┘
       confirmStudents (replace tentative shortlist; may repeat) ⟲
                               │
                     startRoundZero  (requires ≥1 confirmed student)
                               │  writes SHORTLIST history, is_locked = true
                               ▼
                     ┌───────────────────┐  current_round = 0
                     │ ROUND_IN_PROGRESS │  round_stage = RESULT (screening)
                     └─────────┬─────────┘
             ┌─────────────────┼───────────────────────────┐
     advanceRound         completeDrive                     │
   (≥1 SELECTED)         (place SELECTED)                   │
             │                 │                            │
             ▼                 ▼                            │
   current_round = n     ┌───────────┐                      │
   round_stage=PREFILTER │ COMPLETED │  round_stage=NULL    │
             │           └───────────┘                      │
             ▼                                               │
   ┌──────────┐  finalizePrefilter  ┌────────────┐  finalizeAttendance  ┌────────┐
   │ PREFILTER │ ──────────────────►│ ATTENDANCE │ ────────────────────►│ RESULT │
   └──────────┘  (batch REMOVED)    └────────────┘  (requires round     └───┬────┘
                                      date set; batch ABSENT)               │
                                                                            │
                                              advanceRound / completeDrive ◄┘
```

**Transition guards (all return 409 on violation):**
| Action | Precondition | Effect |
|--------|--------------|--------|
| `confirmStudents` | `drive_state = SHORTLISTING` | Replace `drive_students` with the chosen subset (status `SHORTLISTED`, round -1); notify shortlisted. |
| `startRoundZero` | `SHORTLISTING` + ≥1 confirmed | Lock drive; all → `ACTIVE` round 0; write SHORTLIST history; `drive_state=ROUND_IN_PROGRESS`, `round_stage=RESULT`. |
| `advanceRound` | `ROUND_IN_PROGRESS` + `round_stage=RESULT` + ≥1 SELECTED | Resolve results (unchecked → REJECTED); SELECTED → next round ACTIVE; `current_round++`, `round_stage=PREFILTER`. |
| `finalizePrefilter` | `ROUND_IN_PROGRESS` + `round_stage=PREFILTER` + round ≥1 | Batch-mark REMOVED; `round_stage=ATTENDANCE`. |
| `finalizeAttendance` | `round_stage=ATTENDANCE` + round date set | Explicit ABSENT → status ABSENT; write PRESENT/ABSENT history; `round_stage=RESULT`. |
| `markAttendance` | `round_stage=ATTENDANCE` + student ACTIVE | Set transient `attendance_mark` (no status/history change). |
| `completeDrive` | `round_stage=RESULT` | Resolve results; SELECTED → PLACED + `students.placement_status='placed'`; `drive_state=COMPLETED`. |
| `setRoundDate` | round ≤ current_round | Upsert `drive_rounds.round_date`; notify active students if a real date. |
| `updateDrive` | `is_locked = false` | Edit criteria; **clears the shortlist**. |

Every transition loads the drive `FOR UPDATE` first, so concurrent admins are serialized.

---

## 2. Student-in-drive status — `drive_students.status`

Per-student *current* state within one drive ([migration 025](../server/src/migrations/025_drive_students_status.sql)). Vocabulary (CHECK-constrained):

```
 SHORTLISTED ──startRoundZero──► ACTIVE ──┬── finalizePrefilter ──► REMOVED (terminal)
 (round -1)                    (round 0)   │
                                           ├── finalizeAttendance(absent) ──► ABSENT (terminal)
                                           │
                                           ├── advanceRound/complete(unchecked) ──► REJECTED (terminal)
                                           │
                                           └── advanceRound(selected) ──► SELECTED ──► ACTIVE (next round)
                                                                                  └── completeDrive ──► PLACED (terminal)
```

- `SELECTED` is transient: at `advanceRound` selected students are immediately carried forward to the next round as `ACTIVE` (attendance_mark reset); at `completeDrive` they become `PLACED`.
- `REMOVED`, `ABSENT`, `REJECTED`, `PLACED` are terminal for that student in that drive.
- `attendance_mark` (`PRESENT`/`ABSENT`/NULL) is a **transient** per-round mark, editable until `finalizeAttendance` batches it; cleared on each round advance.

Every status change appends an immutable row to `drive_round_history` in the same transaction (see [INVARIANTS.md](INVARIANTS.md)).

---

## 3. Verification — `students.review_status`

Vocabulary: `pending`, `spc_verified`, `spc_rejected`, `verified`, `rejected`. *(No CHECK constraint today — audit recommends adding one; a bulk import once wrote the invalid `'approved'`, repaired by [migration 035](../server/src/migrations/035_normalize_review_status.sql).)*

```
                       ┌─────────┐
  profile complete ──► │ pending │ ◄──────────── edit academic field (BR-15)
                       └────┬────┘
          ┌────────────────┼─────────────────┐
    SPC verify        SPC reject         (SPC is themselves:
          │                │              skip SPC, TPC-direct)
          ▼                ▼                     │
   ┌──────────────┐  ┌──────────────┐            │
   │ spc_verified │  │ spc_rejected │            │
   └──────┬───────┘  └──────┬───────┘            │
          │                 │                    │
     TPC verify        TPC verify / reject       │
          │                 │                    │
          ▼                 ▼                     │
     ┌──────────┐      ┌──────────┐              │
     │ verified │      │ rejected │              │
     └──────────┘      └──────────┘              │
          ▲                                      │
          └──────────── TPC verify ◄─────────────┘
```

- **SPC queue** = assigned students with `review_status = 'pending'`.
- **TPC verification queue** = department students with `review_status = 'spc_rejected'` (SPC rejected them; TPC adjudicates).
- **TPC "awaiting TPC verification"** = department students with `review_status = 'spc_verified'` **plus** SPC coordinators' own records that are still `pending` (SPCs skip SPC review, [tpcController.js:384](../server/src/controllers/tpcController.js)).
- `verified` is the only status that makes a student eligible for drives (BR-18).
- Any verify/reject is department-scoped (TPC) or assignment-scoped (SPC); see [AUTHORIZATION.md](AUTHORIZATION.md).

---

## Extension points
- **Adding a drive stage:** add the value to the `round_stage` CHECK ([migration 024](../server/src/migrations/024_drive_workflow_columns.sql)), a transition endpoint with its guard, and a `drive_round_history` stage/result value ([migration 026](../server/src/migrations/026_create_drive_round_history.sql)). Keep the history append inside the same transaction.
- **Adding a review status:** extend the vocabulary, the queue queries, and (recommended) the new CHECK constraint. Update this file and [STATE_MACHINES.md](STATE_MACHINES.md)'s diagram.
