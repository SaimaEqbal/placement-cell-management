# Environment

Variable **names and purpose only** — never commit real values. `.env` files are git-ignored; only `.env.example` (server) is tracked. Copy the example to `.env` and fill in per environment.

## Server (`server/.env`)
| Variable | Purpose | Required |
|----------|---------|----------|
| `DATABASE_URL` | Postgres connection string (`postgres://user:pass@host:5432/db`). Include `sslmode` for managed Postgres. | ✅ |
| `PORT` | HTTP port (default 3000). | — |
| `JWT_ACCESS_SECRET` | Signs/verifies the access JWT. Rotate → invalidates all sessions. | ✅ |
| `JWT_EMAIL_SECRET` | Separate secret for email-verification & password-reset tokens. | ✅ |
| `FRONTEND_URL` | Frontend origin — used in email links today; **should also drive the CORS allow-list** (currently unused for CORS — audit VULN-11). | ✅ |
| `BREVO_API_KEY` | Brevo transactional-email API key. | ✅ (for email) |
| `BREVO_SENDER_EMAIL` | Verified Brevo sender address. | ✅ (for email) |
| `SUPABASE_URL` | Present in env; **the backend never instantiates a Supabase client** (unused server-side). | — |
| `SUPABASE_ANON_KEY` | Same — unused server-side. Consider removing (audit). | — |
| `GOOGLE_DRIVE_*` | Only for the **deferred** upload feature (`server/src/deferred/`). Not needed by the live app. | — |

**Recommendation (audit):** validate required env at boot (Zod) and fail fast if `DATABASE_URL`/`JWT_ACCESS_SECRET`/`JWT_EMAIL_SECRET` are missing. Add `PG_POOL_MAX`, timeout, and `PGSSL` knobs when tuning the pool ([07-ARCHITECTURE-REVIEW.md](audit-2026-07/07-ARCHITECTURE-REVIEW.md) §3).

## Client (`client/.env`)
| Variable | Purpose | Required |
|----------|---------|----------|
| `VITE_API_BASE_URL` | API base URL (default `http://localhost:3000/api`). The **only** env var the client reads. Baked into the bundle at build time — it is public by design; never put a secret in a `VITE_`-prefixed var. | ✅ |

Only `VITE_`-prefixed vars are exposed to the client bundle (Vite rule). There are no secrets in the frontend (verified). No `.env.example` exists for the client — create one containing just `VITE_API_BASE_URL`.

## Secrets handling
- `server/credentials/google-drive-key.json` — a real Google service credential (deferred use only). Git-ignored, but **should be moved out of the repo tree** into a secret store (audit VULN-06).
- Use a secrets manager (or the platform's env injection) in production; don't ship `.env` files in images.
- Rotating `JWT_ACCESS_SECRET` logs everyone out (no session store); plan for it.
