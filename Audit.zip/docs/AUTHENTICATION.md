# Authentication

Stateless JWT. The server is the security boundary; the client decode is advisory.

## Token model
- **One access token.** `POST /auth/login` signs an HS256 JWT with `JWT_ACCESS_SECRET`, payload `{ userId, role, email }`, **7-day expiry** ([authController.js:518](../server/src/controllers/authController.js)).
- **No refresh token, no rotation, no server-side revocation.** Logout only deletes the client's copy. (Audit VULN-08 — recommended to shorten + add refresh/revocation.)
- **Email/reset tokens** use a *separate* secret `JWT_EMAIL_SECRET` with a `purpose` claim: `email_verification` (24h), `password_reset` (15m). Keeping them on a different secret means a leaked access secret can't mint verification/reset tokens and vice-versa.

## Server verification
`auth` middleware ([authMiddleware.js](../server/src/middleware/authMiddleware.js)):
1. Reads `Authorization: Bearer <token>`; missing → 401.
2. `jwt.verify(token, JWT_ACCESS_SECRET)`; invalid/expired → 401.
3. **Reloads `{id, role}` from `users`** by `decoded.userId`; not found → 401; DB error → 500 (deliberately separated from 401).
4. Sets `req.user = { userId, role }`.

Because role is reloaded every request, **role changes take effect immediately** (a demoted user loses access at once — but a leaked token can't be force-revoked before expiry).

## Flows
| Flow | Endpoint(s) | Notes |
|------|-------------|-------|
| Sign up | `POST /auth/signup` | bcrypt cost 12; sends verification email; user starts unverified |
| Verify email | `GET /auth/verify-email?token=` | matches by email (token stores `email`, not `userId`) |
| Resend verification | `POST /auth/resend-verification` | |
| Login | `POST /auth/login` | requires `is_verified`; returns `{token}` |
| Forgot password | `POST /auth/forgot-password` | non-enumerating (always 200) |
| Reset password | `POST /auth/reset-password` | verifies `purpose=password_reset`; bcrypt cost 12 |
| Staff invite | `/invite/*` | see [WORKFLOWS.md](WORKFLOWS.md) W3; bcrypt cost 10 here (inconsistent — VULN-10) |

## Client handling
- Token stored in `localStorage` key `upms.auth.token` ([tokenStorage.ts](../client/src/api/tokenStorage.ts)) — XSS-exposed (VULN-08).
- Axios request interceptor attaches `Bearer <token>` on every call.
- Axios response interceptor: on 401, clears the token and emits an unauthorized event → `AuthContext` logs out → redirect `/login`.
- `AuthContext` decodes the JWT **unverified** (`lib/jwt.ts`) to derive `{role, userId, email}` for UI gating only. `isTokenExpired` is a client-side convenience check. **Never treat the client decode as a security decision.**

## Password storage
bcrypt hashes only. Costs: 12 in signup/reset, 10 in invite-complete (standardize on 12 — VULN-10). `forgot-password` never reveals whether an email exists.

## Recommendations (audit)
Shorten access-token lifetime; add refresh-token rotation or a `token_version` for revocation on logout/reset/demotion; make reset tokens single-use; consider `httpOnly` cookies (with CSRF protection). See [audit-2026-07/01-VULNERABILITY-REPORT.md](audit-2026-07/01-VULNERABILITY-REPORT.md) VULN-08/09/10.
