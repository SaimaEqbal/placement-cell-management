# Frontend

React 18 + Vite 8 + TypeScript (strict) + React Router 7 + TanStack Query 5 + Axios + Tailwind 4 + shadcn/Radix. Entry: [client/src/main.tsx](../client/src/main.tsx) → [App.tsx](../client/src/App.tsx).

## Structure
```
src/
├─ api/          axiosInstance (single instance + interceptors), tokenStorage, authEvents, apiError
├─ services/     one file per resource; every call goes through axiosInstance, returns res.data
├─ hooks/        TanStack Query wrappers (useDrives, useProfile, useVerification, ...) + queryKeys.ts
├─ context/      AuthContext (decodes JWT, exposes {role,userId,email}, logout)
├─ routes/       AppRoutes (route groups per role), ProtectedRoute (role gate)
├─ pages/        auth(6) student(6) spc(2) tpc(5) admin(8)
├─ components/
│  ├─ ui/        shadcn/Radix primitives (button, dialog, table, select, calendar, ...)
│  └─ dashboard/ app-level shared: StatCard, StudentTable, filters, states.tsx, ConfirmDialog,
│                data-table/ (reusable TanStack Table wrapper + export), announcement + shortlist dialogs
└─ lib/          cgpa.ts (mirror of server), jwt.ts (unverified decode), validation.ts, utils
```

## Data layer
- **One `QueryClient`** ([App.tsx:8](../client/src/App.tsx)): `refetchOnWindowFocus:false`, `staleTime:30s`. (Audit TQ-01 recommends a 4xx-aware `retry` + `mutations.retry:false`.)
- **Query keys** are centralized in [queryKeys.ts](../client/src/hooks/queryKeys.ts) — a hierarchical factory so invalidation never typos a key. Use it; never inline a key array.
- **Services** all go through the shared `axiosInstance`; no direct `fetch`/`axios` calls anywhere. Return `res.data`.
- **Invalidation over refetch:** mutations invalidate the keys they affect (`useDriveWorkflowInvalidator` is the model). `useNotifications` shows the optimistic-update pattern to copy.
- **Errors** normalized to `ApiError` (with `fieldErrors` from server Zod) by the axios interceptor; a 401 triggers global logout.

## Routing & auth
`AppRoutes` wraps route groups in `ProtectedRoute allowedRoles={[...]}` inside `AppShellLayout`. Role comes from `AuthContext` (JWT decode). `spc` is allowed into student routes (dual identity). Guards are **UX only** — the server enforces auth (see [AUTHORIZATION.md](AUTHORIZATION.md)).

## Forms & validation
Manual `useState` + validators in [lib/validation.ts](../client/src/lib/validation.ts) (email/institutional-email, password, phone, SPI, percentage, DOB, `DEPARTMENT_BRANCHES`). No `react-hook-form`/client Zod. Server Zod errors surface as `fieldErrors`. CGPA is previewed client-side ([lib/cgpa.ts](../client/src/lib/cgpa.ts)) but the server value is authoritative.

## Loading/error/empty states
Componentized in [components/dashboard/states.tsx](../client/src/components/dashboard/states.tsx) — use these rather than ad-hoc spinners.

## Styling
Tailwind utilities + shadcn primitives; **black/white theme** (green theme abandoned per `CLAUDE.md`). Mobile-first. Prefer an existing shadcn component before building custom; prefer `components/dashboard/*` shared pieces before new page JSX (project rules in [CLAUDE.md](../CLAUDE.md)).

## Known issues (audit)
- Oversized pages: `admin/DriveStudentsPage.tsx` (991), `admin/DrivesPage.tsx` (777), `student/CompleteProfilePage.tsx` (513) — split into `components/dashboard/drive/*`.
- No ESLint/Prettier; no tests. `noUnusedLocals`/`noUnusedParameters` unset.
- `xlsx` (data-table export) has a high-severity vuln (VULN-16).
- Global `retry:3` retries 4xx and mutations (TQ-01).

## Build
`npm run build` = `tsc --noEmit -p tsconfig.app.json && vite build` (typecheck-gated). **Typecheck the client with** `tsc --noEmit -p tsconfig.app.json` — plain `tsc --noEmit` is a no-op here (see [memory: client-typecheck-command]). No source maps in the prod build (good for secrecy).
