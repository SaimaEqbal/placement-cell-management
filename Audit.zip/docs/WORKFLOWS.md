# Workflows

End-to-end journeys across roles. Each lists the actor, the steps, the endpoints, and the state changes. Cross-references: [STATE_MACHINES.md](STATE_MACHINES.md), [BUSINESS_RULES.md](BUSINESS_RULES.md), [API.md](API.md).

---

## W1. Student onboarding → verified

**Actor:** student (self-serve).

1. **Sign up** — `POST /auth/signup` with institutional email + password. Creates an unverified `users` row; sends a verification email (Brevo). *(bcrypt cost 12.)*
2. **Verify email** — link → `GET /auth/verify-email?token=…`. Sets `users.is_verified = true`. Token matches by email (`purpose=email_verification`, 24h).
3. **Log in** — `POST /auth/login`. Requires `is_verified`. Returns a 7-day JWT.
4. **Complete profile** — the 4-part wizard (Course, Academic, Personal, Documents) each `PUT /students/me` with only its own fields (partial upsert). First save INSERTs the `students` row linked to `user_id`; CGPA is derived server-side when SPIs/semester are present. When all required fields are set, the generated `is_profile_complete` flips true.
5. **Get assigned & reviewed** — the student now appears in the eligible pool for SPC assignment and enters the verification pipeline (W2).

State: `users.is_verified false→true`; `students` created; `review_status = pending`.

---

## W2. Verification pipeline

**Actors:** TPC (assigns + final approval), SPC (first-tier review).

1. **TPC assigns students to SPCs** — `POST /tpc/assign-spc { branch }`. For each (branch, semester) cohort, round-robins complete-profile, non-SPC students across that cohort's SPCs by `spc_id`; writes `students.assigned_spc_id`. Department-scoped to the TPC.
2. **SPC reviews their queue** — `GET /spc/verification-queue` (assigned + `pending`). For each:
   - `PUT /spc/verify/:studentId` → `review_status = spc_verified` (→ TPC final queue).
   - `PUT /spc/reject/:studentId { reason }` → `review_status = spc_rejected` (→ TPC adjudication queue), reason stored.
3. **TPC final review** — two queues:
   - `GET /tpc/spc-verified` (spc_verified + SPCs' own pending records) → `PUT /tpc/verify/:studentId` → `verified`.
   - `GET /tpc/verification-queue` (spc_rejected) → `PUT /tpc/verify` (override to verified) or `PUT /tpc/reject { reason }` → `rejected`.

All SPC actions are assignment-scoped; all TPC actions are department-scoped. A student who later edits an academic field returns to `pending` (BR-15) and re-enters the pipeline.

---

## W3. Staff onboarding (invitation)

**Actors:** admin (invites), invitee (completes).

1. **Admin invites** — `POST /invite/invite { email, role }`, role ∈ {tpc, admin}. Creates an `invitations` row (UUID token, 7-day expiry); emails a `/register/:token` link (best-effort — the link is returned even if email fails).
2. **Invitee opens link** — `GET /invite/verify/:token` returns `{ email, role }` if pending + unexpired.
3. **Invitee completes** — `POST /invite/complete/:token { name, phone, department, branch, password }`. Creates a verified `users` row with the invited role; if `role = tpc`, also inserts a `tpc` profile row. Marks the invitation accepted. *(bcrypt cost 10 here — audit VULN-10.)*

**Role change (existing user):** `PATCH /invite/users/:userId/role` — admin promotes/demotes; provisions a `tpc` row on promotion to TPC, removes it on demotion.

---

## W4. SPC promotion / demotion

**Actor:** TPC (or admin).

- **Promote** — `PUT /tpc/promote-spc/:studentId`. Transaction: validates the student has department + phone (both required by the `spc` table), sets `users.role = 'spc'`, inserts an `spc` row copying name/email/phone/department/branch. Fails with a clear 400 if the profile is incomplete.
- **Demote** — `PUT /tpc/demote-spc/:studentId`. Transaction: `users.role = 'student'`, deletes the `spc` row. Their assigned students' `assigned_spc_id` is set NULL via the FK.

The promoted SPC keeps their student identity and still needs TPC verification (BR-2).

---

## W5. Drive lifecycle (create → shortlist → rounds → placement)

**Actor:** admin. Full state machine in [STATE_MACHINES.md](STATE_MACHINES.md).

1. **Create drive** — `POST /drive` with criteria (company, role, min CGPA, allowed branches/batches, backlog caps, min-CGPA-throughout, number of rounds) and optionally an announcement (created atomically, linked via `company_posts.drive_id`). Response includes the computed eligible list. `drive_state = SHORTLISTING`.
2. **Review & confirm shortlist** — `GET /drive/:id/eligible` (recompute anytime) → admin picks a subset → `POST /drive/:id/confirm-students { studentIds }`. Rows land in `drive_students` as `SHORTLISTED`; students are notified. Re-confirming replaces the tentative list. Editing the drive (`PUT`) here clears the shortlist.
3. **Start Round 0** — `POST /drive/:id/start-round-0`. Locks the drive, moves everyone to `ACTIVE` round 0, writes SHORTLIST history. `drive_state = ROUND_IN_PROGRESS`, `round_stage = RESULT`.
4. **Screening result (round 0)** — from `RESULT`:
   - `POST /drive/:id/advance-round { rejected: [{driveStudentId, reason}] }` — unchecked → REJECTED, rest → SELECTED → carried to round 1 as ACTIVE. Requires ≥1 selected.
   - or `POST /drive/:id/complete { rejected }` — place the selected (screening-only drive).
5. **Each interview round (≥1)** — three sub-stages:
   - **PREFILTER** — `setRoundDate` (optional now, required before attendance), then `POST /drive/:id/finalize-prefilter { removed: [{driveStudentId, reason}] }` — batch REMOVE, → ATTENDANCE.
   - **ATTENDANCE** — per-student `PATCH .../attendance { present }` (transient), then `POST /drive/:id/finalize-attendance` (requires the round date set) — explicit absentees → ABSENT, → RESULT.
   - **RESULT** — `advance-round` (another round) or `complete` (place selected).
6. **Complete** — `POST /drive/:id/complete { rejected }`. SELECTED → PLACED, `students.placement_status='placed'`, `drive_state=COMPLETED`. Placed students drop out of all future eligibility (BR-19).

Every stage notifies the affected students and appends to `drive_round_history` in-transaction.

**Student's view:** `GET /drive/my-drives` (drives they're shortlisted into, with their status/round), `GET /drive/:id/my-results` (their own round-by-round history), `GET /drive/:id/rounds` (schedule).

---

## W6. Announcements

**Actor:** admin.

- **Standalone** — `POST /company-post { title, content, attachments }` (drive_id NULL). Attachments are `{ file_name, file_url }` pasted links, saved transactionally.
- **Drive-linked** — created with the drive (W5 step 1) or as a post with `drive_id` set (UNIQUE — one per drive).
- **Edit** — `PUT /company-post/:id` (title/content; attachments replaced only if the key is sent; `drive_id` not editable here).
- **Delete** — `DELETE /company-post/:id` (attachments cascade; a drive-linked announcement's deletion never deletes the drive).
- **Read** — `GET /company-post` (all, with attachments), any authenticated role.

---

## W7. Notifications

Raised automatically by W5 events (shortlisted, round scheduled, round cleared/failed, removed, absent, placed) — see [BR-25](BUSINESS_RULES.md). Users: `GET /notifications`, `PATCH /notifications/:id/read`, `PATCH /notifications/read-all`, `DELETE /notifications/:id` — all self-scoped. The client uses optimistic updates for read/delete.
