# Testing

**Current state: no automated tests.** `server` has a placeholder `npm test` (`exit 1`); `client` build runs `tsc --noEmit` only. There is no test runner, no CI, no coverage. This is the single biggest risk multiplier for the codebase — every refactor is unguarded, and the authorization gaps have no regression net.

This doc is the recommended strategy (from audit [07-ARCHITECTURE-REVIEW.md](audit-2026-07/07-ARCHITECTURE-REVIEW.md) §6), risk-ranked.

## Priority pyramid

| Layer | Priority | Tooling | Cover first |
|-------|----------|---------|-------------|
| **API / integration** | **P0** | `supertest` + ephemeral Postgres | The [authorization matrix](audit-2026-07/02-AUTHORIZATION-MATRIX.md): one test per endpoint asserting the right roles pass and wrong roles get 403/401. This is the regression net for VULN-01–04. Plus the verification pipeline and each drive transition guard. |
| **Unit** | P1 | `vitest` | `lib/cgpa.js` (weighting, completed-semester edges, nulls), eligibility predicate, review-flag logic, `lib/dbError.js`. Pure functions, cheap, high value. |
| **Migration** | P1 | CI job | Apply all migrations to a fresh DB and assert the schema matches [schema.md](../schema.md). Would have caught the 003/004 defects. |
| **Frontend component** | P2 | `vitest` + Testing Library | Workflow pages, verification detail, form validation paths. |
| **E2E** | P2 | Playwright | The 3 journeys: student profile→verified; drive create→shortlist→rounds→placement; invite→staff onboarding. |
| **Security** | P2 | CI | Automate the authz tests + `npm audit`/dependency scan (flags VULN-16 `xlsx`). |
| **Performance** | P3 | `EXPLAIN ANALYZE` + k6 | Seed realistic data; measure hot queries pre/post-index; smoke-test list endpoints once paginated. |

## First move
Stand up **GitHub Actions**: typecheck (both apps) + lint (once ESLint is added) + the P0 API authz suite against an ephemeral Postgres service container. That one pipeline converts the two scariest risks — silent authz regressions and unreplayable migrations — into build failures.

## Test data
- Use a **separate test database** seeded per-run (transaction-per-test or truncate-between). Never point tests at a real DB.
- Seed helpers should create a user per role (student, spc, tpc, admin) + a department so scoping tests are meaningful.
- Respect the invariants when seeding: canonical department strings (INV-4), valid `review_status` vocabulary (INV-6), SPC created via the promote path (INV-2).

## What a good authz test looks like
For each protected endpoint, assert:
1. No token → 401.
2. Wrong role → 403.
3. Right role, wrong scope (e.g. SPC acting on an unassigned student, TPC on another department) → 404/403.
4. Right role + scope → 2xx.

Case (3) is what would have caught VULN-02/03 and the department-scoping gaps.

## Adding tests to a change
Any change to a controller's SQL, a transition guard, or a scoping clause should ship with a test covering the new behavior and the negative case. Until the harness exists, at minimum add the harness for the area you touch.
