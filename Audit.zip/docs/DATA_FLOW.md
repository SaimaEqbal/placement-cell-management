# Data Flow

How a request travels through the system, and how derived data and notifications propagate.

---

## 1. Request path (read)

```
React page/component
  └─ useQuery (hooks/useX.ts, key from queryKeys.ts)
      └─ service fn (services/xService.ts)
          └─ axiosInstance (api/axiosInstance.ts)  ── attaches Authorization: Bearer <jwt> from localStorage
              └─ HTTP GET /api/...
                  └─ Express router (routes/index.js → routes/xRoutes.js)
                      └─ auth middleware        (verify JWT, reload {id, role} from users)
                          └─ role middleware    (requireAdmin / requireAdminTPC / ...)
                              └─ controller      (parameterized pg query via pool)
                                  └─ PostgreSQL
                              ◄── rows
                      ◄── res.json(data)      (shape varies — see API.md)
          ◄── res.data (services return res.data)
      ◄── cached under the query key (staleTime 30s)
  ◄── render; loading/error/empty via components/dashboard/states.tsx
```

**Error path:** a controller catch maps DB errors through `lib/dbError.js` (`pgErrorResponse` → `{status, message}`), returns a generic message (no stack trace). The Axios response interceptor normalizes errors into an `ApiError` with `fieldErrors` (from Zod). A 401 clears the token and emits an unauthorized event → `AuthContext` logs out → `ProtectedRoute` redirects to `/login`.

---

## 2. Request path (mutation + side effects)

```
useMutation (hooks) ─► service ─► axios ─► route ─► auth/role/validate ─► controller
                                                                            │
                                                          pool.connect(); BEGIN
                                                            ├─ load parent FOR UPDATE (drives) / check state
                                                            ├─ UPDATE/INSERT domain rows (drive_students, students)
                                                            ├─ INSERT drive_round_history  (audit, same txn)  [INV-11]
                                                            └─ INSERT notifications         (same txn)         [BR-25]
                                                          COMMIT (or ROLLBACK on any error)
                                                          client.release()
                                                            │
                        onSuccess ◄── res.json ◄────────────┘
                          └─ queryClient.invalidateQueries({ affected keys })
                              └─ dependent useQuery refetches
```

Key property: **domain change, audit history, and notifications commit atomically.** A student is notified iff the action that concerns them succeeded. Nothing is written to history without the matching status change.

---

## 3. Derived-data flow

```
student submits SPIs + semester (PUT /students/me, partial)
   └─ computeCgpaRounded(spis, semester)   [lib/cgpa.js, server-authoritative]  [INV-16]
       └─ students.cgpa written
           └─ is_profile_complete recomputed by the DB (generated STORED column) [INV-17]
               └─ eligibility engine reads cgpa + is_profile_complete at drive time (never stored) [BR-18]
```

Eligibility is computed on demand from live student data every time (`getEligibleStudentsForDrive`), so it always reflects the current profile and placement status.

---

## 4. Notification fan-out

Domain events raise notifications via helpers on the notifications controller/service, inside the triggering transaction:
- `notifyStudentsByIds(client, ids, title, msg, tone)` — resolves `students.id → users.id`, inserts one row per user in a single `INSERT ... SELECT` ([driveController.js:112](../server/src/controllers/driveController.js)).
- `createNotificationForRole(role, ...)` — broadcast to every user of a role in one query.

Events: shortlisted, round scheduled, round cleared / not cleared, removed (prefilter), marked absent, placed. Users poll `GET /notifications` (self-scoped); the client applies optimistic read/delete.

---

## 5. Auth state flow (client)

```
login ─► { token } ─► tokenStorage.set (localStorage "upms.auth.token")
   └─ AuthContext.deriveState: decode JWT (unverified, UI-only) → { role, userId, email }
       └─ ProtectedRoute gates routes by allowedRoles
           └─ every request: axios attaches the token
               └─ 401 anywhere ─► authEvents.emitUnauthorized ─► AuthContext logout ─► redirect /login
```

The client decode is **advisory only** — the server is the security boundary (it re-verifies the JWT and reloads the role every request). See [AUTHENTICATION.md](AUTHENTICATION.md).

---

## 6. Where state lives

| State | Home | Notes |
|-------|------|-------|
| Server/domain data | PostgreSQL | single source of truth |
| Cached server data | TanStack Query cache | keyed, 30s stale, invalidated on mutation |
| Auth token | `localStorage` | XSS-exposed (audit VULN-08) |
| Auth-derived identity | `AuthContext` (React) | decoded from token |
| Ephemeral UI state | component `useState` | forms, dialogs, filters |
| Route | React Router | role-gated by `ProtectedRoute` |

There is no client-side global store (Redux/Zustand); server state is TanStack Query, UI state is local. This is deliberate and keeps the data flow one-directional.
