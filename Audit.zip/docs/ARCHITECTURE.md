# Architecture

## System

A two-tier web application for a college placement cell.

```
┌─────────────────────────────┐        HTTPS/JSON        ┌──────────────────────────────┐
│  Client (client/)           │  ── Bearer JWT ──►       │  Server (server/)            │
│  React 18 + Vite + TS       │                          │  Express 5 (ESM) + pg        │
│  React Router 7             │  ◄── JSON ──             │  raw SQL, no ORM             │
│  TanStack Query 5           │                          │  Zod validation              │
│  Tailwind 4 + shadcn/Radix  │                          │  JWT (jsonwebtoken)          │
│  Axios (single instance)    │                          │  bcrypt, Brevo email         │
└─────────────────────────────┘                          └──────────────┬───────────────┘
                                                                          │ pg Pool
                                                                          ▼
                                                              ┌──────────────────────┐
                                                              │  PostgreSQL           │
                                                              │  14 tables, manual    │
                                                              │  SQL migrations       │
                                                              └──────────────────────┘
```

- **No BFF, no server-side rendering.** The client is a static SPA that talks to the API over `VITE_API_BASE_URL`.
- **No ORM.** Controllers issue parameterized SQL through a shared `pg` pool.
- **Email** via Brevo (`@getbrevo/brevo`). **Auth** is stateless JWT (no session store).
- **Deferred:** a Google-Drive document-upload feature exists in `server/src/deferred/` but is not mounted; the live app uses pasted URLs.

## Repository layout

```
client/                      # repo root
├─ client/                   # React SPA
│  ├─ src/
│  │  ├─ api/                # axiosInstance, tokenStorage, authEvents, apiError
│  │  ├─ services/           # one file per resource; all calls via axiosInstance
│  │  ├─ hooks/              # TanStack Query wrappers + queryKeys.ts
│  │  ├─ context/            # AuthContext
│  │  ├─ routes/             # AppRoutes, ProtectedRoute
│  │  ├─ pages/{auth,student,spc,tpc,admin}/
│  │  ├─ components/{ui,dashboard}/   # shadcn primitives + app-level shared
│  │  └─ lib/                # cgpa.ts, jwt.ts, validation.ts, utils
│  └─ .env                   # VITE_API_BASE_URL (gitignored)
├─ server/
│  ├─ src/
│  │  ├─ index.js            # app entry (middleware + listen)
│  │  ├─ config/db.js        # pg Pool
│  │  ├─ routes/             # 9 routers, mounted in routes/index.js
│  │  ├─ controllers/        # HTTP + SQL (no service layer yet)
│  │  ├─ middleware/         # authMiddleware, roleMiddleware, *Middleware (Zod validators)
│  │  ├─ lib/                # cgpa, dbError, announcements, schema (Zod)
│  │  ├─ services/           # emailService
│  │  ├─ migrations/         # 001–037, applied by hand
│  │  └─ deferred/           # archived Google-Drive upload feature (unwired)
│  ├─ credentials/           # google-drive-key.json (gitignored; deferred use only)
│  └─ .env                   # DATABASE_URL, JWT secrets, Brevo, etc. (gitignored)
├─ schema.md                 # current DB column reference (2026-07-12)
├─ docs/                     # this documentation pack
└─ audit/                    # stale 2026-07-06 audit (superseded by docs/audit-2026-07/)
```

## Request lifecycle
See [DATA_FLOW.md](DATA_FLOW.md). In short: page → `useQuery`/`useMutation` → service → axios (+JWT) → router → `auth` → role middleware → Zod validator → controller → `pg`. Mutations run in transactions that also write audit history and notifications atomically.

## Roles
`student`, `spc` (a promoted student), `tpc` (department staff), `admin` (unscoped). See [AUTHORIZATION.md](AUTHORIZATION.md).

## Key design decisions (and why)
| Decision | Rationale |
|----------|-----------|
| Raw SQL over an ORM | Full control of the multi-round workflow's transactions and locking; small schema. |
| Admin-driven shortlisting, no student applications | The placement cell drives the process; eligibility is objective/computed (BR-17). |
| Server-authoritative CGPA & generated completeness flag | Students can't game eligibility (INV-16/17). |
| Denormalized department strings | Simplicity; comes with the string-match fragility (INV-4) — a known trade-off. |
| Append-only `drive_round_history` | Immutable audit trail decoupled from mutable current state (INV-11). |
| Stateless JWT | No session store; simple horizontal scaling — at the cost of revocation (audit VULN-08). |
| TanStack Query as the only "store" | Server state cached/invalidated centrally; UI state stays local (DATA_FLOW §6). |

## Known gaps
See the production-readiness audit: [audit-2026-07/00-EXECUTIVE-SUMMARY.md](audit-2026-07/00-EXECUTIVE-SUMMARY.md). Highest priority: authorization gaps (VULN-01–04), platform hardening (CORS/helmet/rate-limit), and migration replayability.
